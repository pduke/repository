// IR-KeepAlive.c
// Send IR remote codes to Dish receiver every hour
// so it won't go to sleep.
//
// Sends Select code followed by Cancel.

#include <stdlib.h>
#include <stdbool.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/sleep.h>
#include <avr/power.h>
#include <util/delay.h>
#include <libNoter/pin_io_macros.h>

#define SELECT 0xBFFF
#define CANCEL 0xB7FF

#define IR_LED          B,0   // OCR0A
#define STATUS_LED      B,1   // OCR0B

#define PERIOD_SECONDS 3600  // ~ once an hour
volatile uint16_t elapsed_seconds = PERIOD_SECONDS;

ISR(WDT_vect, ISR_BLOCK){
  elapsed_seconds += 8;
}

void pwm_on(){
  // config timer0 for ~ 56 kHZ as measured with scope
  ICR0 = 138;
  OCR0A = 69;
  TCNT0 = 0;
  GTCCR = _BV(PSR);
  TCCR0A = _BV(COM0A0) | _BV(COM0A1) | _BV(WGM01);
  TCCR0B = _BV(CS00) | _BV(WGM03) | _BV(WGM02);
}

void pwm_off(){
  TCCR0B = 0;
  TCCR0A = 0;
  CLEAR(IR_LED);
}

void send_mark(){
  pwm_on();
  _delay_us(420);
  pwm_off();
  _delay_us(6000);
}

void send_1(){
  pwm_on();
  _delay_us(420);
  pwm_off();
  _delay_us(2500);
}

void send_0(){
  pwm_on();
  _delay_us(420);
  pwm_off();
  _delay_us(1500);
}

void blink(){
  // blink and pwm_on/off are mutually exclusive
  // because they both user timer0
  ICR0 = 500;
  OCR0B = 1;
  TCNT0 = 0;
  GTCCR = _BV(PSR);
  TCCR0A = _BV(COM0B1) | _BV(WGM01);
  TCCR0B = _BV(CS00) | _BV(WGM03) | _BV(WGM02);
  _delay_ms(100);
  TCCR0B = 0;
  TCCR0A = 0;
  CLEAR(STATUS_LED);
  _delay_ms(100);
}

void send_code(uint16_t code){
  uint8_t i;
  uint8_t i1;
  uint16_t t_code;
  for(i=0;i<4;i++){
    t_code = code;
    send_mark();
    for(i1=0;i1<16;i1++){
      if(t_code & 0x8000){
        send_1();
      } else {
        send_0();
      }
      t_code = t_code << 1;
    }
  }
  send_mark();
}

//---------------------------------------------------------------------------------------
void main() {
  // bump clock to 8MHz
  CCP = 0xD8;   // enable protected change
  CLKPSR = 0;   // set 8MHz prescaler = 1

  // power reduction
  ACSR = _BV(ACD);                                                // shutdown analog comparator
  DIDR0 = (_BV(ADC0D) | _BV(ADC1D)  | _BV(ADC2D) | _BV(ADC3D));   // disable digital inputs
  power_adc_disable();                                            // disable adc

  // setup ports
  OUTPUT(IR_LED);
  OUTPUT(STATUS_LED);

  // startup watchdog timer
  CCP = 0xD8;                     // enable protected change
  WDTCSR = _BV(WDP3) | _BV(WDP0); // 8 second timeout
  WDTCSR |= _BV(WDIE);            // interrupt on timeout
  sei();                          // enable global interrupts

  // blink status led on startup
  blink();
  blink();

  for(;;){
    if(elapsed_seconds >= PERIOD_SECONDS){
      // send codes
      cli();
      send_code(SELECT);
      _delay_ms(100);
      send_code(CANCEL);
      elapsed_seconds = 0;
      blink();
      sei();
    }
    // powerdown sleep until watchdog wakeup
    set_sleep_mode(SLEEP_MODE_PWR_DOWN);
    sleep_enable();
    sleep_cpu();
    sleep_disable();
  }    
}


