EAGLE AutoRouter Statistics:

Job           : /home/paul/AVR/IR-KeepAlive-Tiny10/IR-KeepAlive-PCB/IR-KeepAlive.brd

Start at      : 17:19:01 (4/14/14)
End at        : 17:19:01 (4/14/14)
Elapsed time  : 00:00:00

Signals       :     4   RoutingGrid: 10 mil  Layers: 2
Connections   :     6   predefined:  3 ( 0 Vias )

Router memory :   15128

Passname          :    Busses     Route Optimize1 Optimize2 Optimize3 Optimize4

Time per pass     :  00:00:00  00:00:00  00:00:00  00:00:00  00:00:00  00:00:00
Number of Ripups  :         0         0         0         0         0         0
max. Level        :         0         0         0         0         0         0
max. Total        :         0         0         0         0         0         0

Routed            :         0         3         3         3         3         3
Vias              :         0         1         0         0         0         0
Resolution        :    50.0 %   100.0 %   100.0 %   100.0 %   100.0 %   100.0 %

Final             : 100.0% finished
