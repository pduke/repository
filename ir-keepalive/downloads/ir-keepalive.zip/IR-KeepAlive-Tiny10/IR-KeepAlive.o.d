IR-KeepAlive.o: IR-KeepAlive.c ../libNoter/pin_io_macros.h

../libNoter/pin_io_macros.h:
