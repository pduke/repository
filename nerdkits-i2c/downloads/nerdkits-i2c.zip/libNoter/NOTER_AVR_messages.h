//
// NOTER_AVR_messages.h
//
//	v1.1  3/24/2011
// 
// Define message formats used between the AVR and NOTER_AVRserv on the host PC
//
#ifndef __NOTER_AVR_messages
#define __NOTER_AVR_messages

#define MSG_ESC			0x1C

#define	PUT_TIME_CMD	0x01
#define	GET_TIME_CMD	0x02
#define	ACK_CMD			0xFE

typedef struct {
	unsigned char		cmd; // cmd will always be the 1st byte of a message
	//
	unsigned char		hour;
	unsigned char		minute;
	unsigned char		second;
	unsigned char		hundredth;
	//
	unsigned int		year;
	unsigned char 		month;
	unsigned char 		day;
	//
	unsigned char		day_of_week;
} PUT_TIME_MSG;

typedef struct {
	unsigned char		msg_esc;
	unsigned char		msg_len;
	unsigned char		msg_crc;
	unsigned char		msg_cmd_data[1]; // all of message in buffer starting here with 1st byte
} MSG_WRAP;

unsigned char 	msg_buff[sizeof(MSG_WRAP)+sizeof(PUT_TIME_MSG)];

MSG_WRAP		*p_msg_wrap;
PUT_TIME_MSG	*p_put_time_msg;

void init_msg();
unsigned char make_crc(unsigned char *data, int length);
int send_msg(unsigned char *buffer, unsigned char length);
int get_msg();

#endif