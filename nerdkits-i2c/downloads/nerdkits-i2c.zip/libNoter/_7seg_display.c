// _7seg_display.c
// 
// Library object that provides messaging to the remote display via TWI.
//

#include <inttypes.h>
#include "../libNoter/_7seg_display.h"
#include "../libNoter/TWI.h"

// Supported funcitons ----------------------------------------------------- 

// display hex digits
void _7seg_display_hex(uint8_t slave_addr, int16_t hex_value, uint8_t colon, uint8_t apostrophe){
	// don't put anything in the TWI buffer if the TWI driver is busy
	while(TWI_busy);
	p_7seg_display_hex_msg->command = v_7seg_display_hex_cmd;
	p_7seg_display_hex_msg->hex_value = hex_value;
	p_7seg_display_hex_msg->colon_on = colon;
	p_7seg_display_hex_msg->apostrophe_on = apostrophe;
	TWI_master_start_write(		slave_addr,	// device address of eeprom chip
								sizeof(_7seg_display_hex_msg)		// number of bytes to write
								);
}

// display an integer
void _7seg_display_int(uint8_t slave_addr, int16_t int_value, uint8_t colon, uint8_t apostrophe){
	while(TWI_busy);
	p_7seg_display_int_msg->command = v_7seg_display_int_cmd;
	p_7seg_display_int_msg->int_value = int_value;
	p_7seg_display_int_msg->colon_on = colon;
	p_7seg_display_int_msg->apostrophe_on = apostrophe;
	TWI_master_start_write(		slave_addr,	// device address of eeprom chip
								sizeof(_7seg_display_int_msg)		// number of bytes to write
								);
}

// display a double precision floating point number
void _7seg_display_dbl(uint8_t slave_addr, double dbl_value, uint8_t colon, uint8_t apostrophe){
	while(TWI_busy);
	p_7seg_display_dbl_msg->command = v_7seg_display_dbl_cmd;
	p_7seg_display_dbl_msg->dbl_value = dbl_value;
	p_7seg_display_dbl_msg->colon_on = colon;
	p_7seg_display_dbl_msg->apostrophe_on = apostrophe;
	TWI_master_start_write(		slave_addr,	// device address of eeprom chip
								sizeof(_7seg_display_dbl_msg)		// number of bytes to write
								);
}

// turn on/off display blinking and set a blink rate
void _7seg_set_blink(uint8_t slave_addr, uint8_t blink_on, uint16_t ms_cycle){
	while(TWI_busy);
	p_7seg_set_blink_msg->command = v_7seg_set_blink_cmd;
	p_7seg_set_blink_msg->blink_state = blink_on;
	p_7seg_set_blink_msg->cycle_ms = ms_cycle;
	TWI_master_start_write(		slave_addr,	// device address of eeprom chip
								sizeof(_7seg_set_blink_msg)		// number of bytes to write
								);
}

// run a predefined pattern on the display
void _7seg_invoke_pattern(uint8_t slave_addr, uint8_t pattern, uint16_t ms_cycle){
	while(TWI_busy);
	p_7seg_invoke_pattern_msg->command = v_7seg_invoke_pattern_cmd;
	p_7seg_invoke_pattern_msg->cycle_ms = ms_cycle;
	p_7seg_invoke_pattern_msg->pattern = pattern;
	TWI_master_start_write(		slave_addr,	// device address of eeprom chip
								sizeof(_7seg_invoke_pattern_msg)		// number of bytes to write
								);
}

// individual segment control
void _7seg_light_segments(uint8_t slave_addr, uint8_t num_digits, uint8_t *digits, uint8_t colon, uint8_t apostrophe){
	uint8_t i;
	while(TWI_busy);
	p_7seg_specific_segs_msg->command = v_7seg_specific_segs_cmd;
	for(i=0;i<num_digits;i++){
		p_7seg_specific_segs_msg->segs[i] = digits[i];
	}
	p_7seg_specific_segs_msg->colon_on = colon;
	p_7seg_specific_segs_msg->apostrophe_on = apostrophe;
	TWI_master_start_write(		slave_addr,	// device address of eeprom chip
								sizeof(_7seg_specific_segs_msg)	+ num_digits	// number of bytes to write
								);
}

// turn brightness up/down
void _7seg_set_brightness(uint8_t slave_addr, uint8_t brightness){
	while(TWI_busy);
	p_7seg_set_brightness_msg->command = v_7seg_set_brightness_cmd;
	p_7seg_set_brightness_msg->brightness = brightness;
	TWI_master_start_write(		slave_addr,	// device address of eeprom chip
								sizeof(_7seg_set_brightness_msg)		// number of bytes to write
								);
}

// get some information from the slave display - number of digits, etc.
void _7seg_get_display_info(uint8_t slave_addr, uint8_t *digits, uint8_t *decimals, uint8_t *colons, uint8_t *apostrophes){
	// get display info
	while(TWI_busy);
	p_7seg_get_info_msg->command = v_7seg_get_info_cmd;
	TWI_master_start_write_then_read(	slave_addr,	// device address of eeprom chip
										sizeof(_7seg_get_info_msg),		// number of bytes to write
										sizeof(_7seg_info_reply)		// number of bytes to read
										);
	while(TWI_busy);
	if(!TWI_error){
		*digits = p_7seg_info_reply->digit_count;
		*decimals = p_7seg_info_reply->decimal_point_count;
		*colons = p_7seg_info_reply->colon_count;
		*apostrophes = p_7seg_info_reply->apostrophe_count;
	}
}

// display time
void _7seg_display_time(uint8_t slave_addr, uint8_t hours, uint8_t minutes, uint8_t seconds){
	while(TWI_busy);
	p_7seg_display_time_msg->command = v_7seg_display_time_cmd;
	p_7seg_display_time_msg->hour = hours;
	p_7seg_display_time_msg->minute = minutes;
	p_7seg_display_time_msg->second = seconds;
	TWI_master_start_write(		slave_addr,	// device address of eeprom chip
								sizeof(_7seg_display_time_msg)		// number of bytes to write
								);
}

// initialize buffers, callback function pointers, and the TWI
void _7seg_init(uint32_t f_cpu, uint32_t i2c_bitrate, void (*I2C_callback)(volatile uint8_t TWI_match_addr, uint8_t return_code)){
	// set buffer pointers
	p_7seg_display_cmd = (_7seg_display_cmd *)TWI_buffer;
	p_7seg_display_int_msg = (_7seg_display_int_msg *)TWI_buffer;
	p_7seg_display_dbl_msg = (_7seg_display_dbl_msg *)TWI_buffer;
	p_7seg_invoke_pattern_msg = (_7seg_invoke_pattern_msg *)TWI_buffer;
	p_7seg_set_blink_msg = (_7seg_set_blink_msg *)TWI_buffer;
	p_7seg_display_hex_msg = (_7seg_display_hex_msg *)TWI_buffer;
	p_7seg_specific_segs_msg = (_7seg_specific_segs_msg *)TWI_buffer;
	p_7seg_set_brightness_msg = (_7seg_set_brightness_msg *)TWI_buffer;
	p_7seg_get_info_msg = (_7seg_get_info_msg *)TWI_buffer;
	p_7seg_info_reply = (_7seg_info_reply *)TWI_buffer;
	p_7seg_display_time_msg = (_7seg_display_time_msg *)TWI_buffer;
	
	// Specify startup parameters for the TWI/I2C driver
	TWI_init(	f_cpu, 						// clock frequency
				i2c_bitrate,				// desired TWI/IC2 bitrate
				TWI_buffer, 				// pointer to comm buffer
				sizeof(TWI_buffer), 		// size of comm buffer
				I2C_callback				// pointer to callback function
				);
}

