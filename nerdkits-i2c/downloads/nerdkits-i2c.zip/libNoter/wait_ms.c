// wait_ms.c
// 
// Library object that provides interrupt driven ms waits/function call.
// Uses 8-bit timer/counter0
//
#include <avr/interrupt.h>
#include "wait_ms.h" 

#define Timer0_stopped		0
#define Timer0_div_1		1
#define Timer0_div_8		2
#define Timer0_div_64		3
#define Timer0_div_256		4
#define Timer0_div_1024		5
#define Timer0_div_ext_f	6
#define Timer0_div_ext_r	7

// initialize timer
void wait_ms_init(uint32_t f_cpu){
	switch (f_cpu){
		case 20000000L: // 1.0016025641025641025641025641026 ms
			TCCR0B = Timer0_div_256;
			OCR0A = 78; 
			break;
		case 18432000L: // 1.0 ms
			TCCR0B = Timer0_div_256;
			OCR0A = 72; 
			break;
		case 14745600L: // 1.001739130434782608695652173913 ms
			TCCR0B = Timer0_div_64;
			OCR0A = 230; 
			break;
		case 8192000L:  // 1.0 ms
			TCCR0B = Timer0_div_64;
			OCR0A = 128; 
			break;
		default:
		case 8000000L:  // 1.0 ms
			TCCR0B = Timer0_div_64;
			OCR0A = 125; 
			break;
		case 7372800L:  // 1.001739130434782608695652173913 ms
			TCCR0B = Timer0_div_64;
			OCR0A = 115; 
			break;
	} 
	TCCR0A = (1<<WGM01); // CTC mode
	TIMSK0 = (1<<OCIE0A); // interrupt on OCR0A match
}

// simple delay timer
void wait_ms(uint16_t ms){
	wait_count=ms;
	while(wait_count>0);
	}

// timer with callback for additional processing
void wait_ms_init_callback(uint32_t f_cpu, void (*callback)()){
	wait_callback = callback;
	wait_ms_init(f_cpu);
}

// routine to handle timer interrupts
SIGNAL(TIMER0_COMPA_vect){
	if(wait_count>0){
		wait_count--;
	}
	if(wait_callback){
		(*wait_callback)();
	}
}

