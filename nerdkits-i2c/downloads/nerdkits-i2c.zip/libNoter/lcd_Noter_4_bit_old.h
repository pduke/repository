#ifndef __LCD_NOTER_4_BIT_H
#define __LCD_NOTER_4_BIT_H

static inline void lcd_set_type_data(void);
static inline void lcd_set_type_command(void);
void lcd_write_nibble(char c);
void lcd_write_byte(char c);
void lcd_clear_and_home(void);
void lcd_home(void);
void lcd_write_data(char c);
void lcd_write_string(const char *x);
void lcd_line_one(void);
void lcd_line_two(void);
void lcd_line_three(void);
void lcd_line_four(void);
void lcd_goto_position(uint8_t row, uint8_t col);
void lcd_init(void);
char lcd_read_nibble(void);
char lcd_read_byte(void);
void lcd_set_data_pins_output(void);
void lcd_set_data_pins_input(void);
void lcd_busy_wait_4_bit(void);
static inline void lcd_delay_ms_or_wait(uint16_t count);
static inline void lcd_delay_us_or_wait(uint16_t count);

#include <stdio.h>
int lcd_putchar(char x, FILE *stream);

// for NerdKits
// original - mrobbins@mit.edu
//
// modified by PDuke (Noter) for dynamic pin assignments
// and use of busy/ready flag. Put source in .h file for local
// compile using F_CPU value for util/delay.
//

#include <avr/io.h>
#include <avr/pgmspace.h>
#include <inttypes.h>
#include <stdio.h>
#include <util/delay.h>
#include <libNoter/pin_io_macros.h>

// define ports, pins
//		To use timeouts and only 6 mcu pins, remove the definition of LCD_RW.
//		With LCD_RW defined the ready/busy flag will be used.
//

#if defined(__AVR_ATmega168__) || defined(__AVR_ATmega328P__)
	#define LCD_RS			D,2		// Register Select
	#define LCD_RW			D,3		// Read/Write
	#define LCD_E			D,4		// Enable data transfer
	#define LCD_DB4		D,5		// Data bits ...
	#define LCD_DB5		D,6
	#define LCD_DB6		D,7
	#define LCD_DB7		B,0		// also Ready/Busy flag

#elif defined(__AVR_ATmega32U4__)

	#define LCD_RS			D,4
	#define LCD_RW			D,6
	#define LCD_E			D,7
	#define LCD_DB4		B,4
	#define LCD_DB5		B,5
	#define LCD_DB6		B,6
	#define LCD_DB7		C,6

#elif defined(__AVR_AT90USB162__)

	#define LCD_RS			C,2
	#define LCD_RW			D,0
	#define LCD_E			D,1
	#define LCD_DB4		D,2
	#define LCD_DB5		D,3
	#define LCD_DB6		D,4
	#define LCD_DB7		D,5

#else
	#error !cpu not supported by lcd_new.h
#endif

// UC-204 LCD Display pin-outs
//
//	1	GND
//	2	VCC
//	3	VO 	(contrast resistor to GND)
//	4	RS 	(register select)
//	5	R/W	(read/write)
//	6	E	(enable)
//	7	DB0
//	8	DB1
//	9	DB2
//	10	DB3
//	11	DB4
//	12	DB5
//	13	DB6
//	14	DB7
//	15	LED+(backlight)
//	16	LED-

#define SCROLL
#define LINES 4
#define CHARS 20
volatile uint8_t DDRAM_address=0;

void lcd_set_data_pins_output(){
	OUTPUT(LCD_DB4);	CLEAR(LCD_DB4);
	OUTPUT(LCD_DB5);	CLEAR(LCD_DB5);
	OUTPUT(LCD_DB6);	CLEAR(LCD_DB6);
	OUTPUT(LCD_DB7);	CLEAR(LCD_DB7);
	_delay_us(1);
}

#ifdef LCD_RW
	void lcd_set_data_pins_input(){
		PULLUP_OFF(LCD_DB4);
		PULLUP_OFF(LCD_DB5);
		PULLUP_OFF(LCD_DB6);
		PULLUP_OFF(LCD_DB7);
		_delay_us(1);
	}

	char lcd_read_nibble(){
		char tmp;
		SET(LCD_E);
		_delay_us(1);
		tmp = (READ(LCD_DB7)<<3)	
			| (READ(LCD_DB6)<<2)
			| (READ(LCD_DB5)<<1)
			| (READ(LCD_DB4));
		CLEAR(LCD_E);
		return(tmp);
	}

	char lcd_read_byte(){
		SET(LCD_RW);
		char tmp;
		lcd_set_data_pins_input();
		tmp=lcd_read_nibble()<<4;
		tmp|=lcd_read_nibble();
		lcd_delay_us_or_wait(50);
		return(tmp);
	}

	void lcd_busy_wait_4_bit(){
		char tmp;
		tmp=0x80;
		lcd_set_type_command();
		SET(LCD_RW);
		lcd_set_data_pins_input();
		while(tmp&0x80){
			tmp=lcd_read_nibble()<<4;
			tmp|=lcd_read_nibble();
		}
		DDRAM_address = tmp;
	}
#endif

static inline void lcd_delay_ms_or_wait(uint16_t count){
	#ifndef LCD_RW
		while(--count) _delay_ms(1);
	#else
		lcd_busy_wait_4_bit();
	#endif
}

static inline void lcd_delay_us_or_wait(uint16_t count){
	#ifndef LCD_RW
		while(--count) _delay_us(1);
	#else
		lcd_busy_wait_4_bit();
	#endif
}

// lcd_set_type_data()
static inline void lcd_set_type_data(){
	SET(LCD_RS);
}

// lcd_set_type_command()
static inline void lcd_set_type_command(){
	CLEAR(LCD_RS);
}

// lcd_write_nibble(...)
void lcd_write_nibble(char data){
	#ifdef LCD_RW
		CLEAR(LCD_RW);
		lcd_set_data_pins_output();
	#endif
	if(data & 0x01) SET(LCD_DB4); else 	CLEAR(LCD_DB4);
	if(data & 0x02) SET(LCD_DB5); else	CLEAR(LCD_DB5);
	if(data & 0x04) SET(LCD_DB6); else 	CLEAR(LCD_DB6);
	if(data & 0x08) SET(LCD_DB7); else 	CLEAR(LCD_DB7);
	SET(LCD_E);
	_delay_us(1);
	CLEAR(LCD_E);
	_delay_us(1);
}

void lcd_write_byte(char c){
	lcd_write_nibble( (c >> 4) & 0x0f );
	lcd_write_nibble( c & 0x0f );
	lcd_delay_us_or_wait(50);
}

void lcd_clear_and_home(){
	lcd_set_type_command();
	lcd_write_byte(0x01);
	_delay_ms(2);
	lcd_write_byte(0x02);
	_delay_ms(2);
}

void lcd_home(){
	lcd_set_type_command();
	lcd_write_byte(0x02);
	_delay_ms(2);
}

void lcd_write_data(char c){
#ifndef LCD_RW
	lcd_set_type_data();
	lcd_write_byte(c);
#else
	#ifndef SCROLL
		lcd_set_type_data();
		lcd_write_byte(c);
	#else
	if((c==0x0D)|(c==0x0A)){					// process lf or cr
		if(DDRAM_address<20) DDRAM_address = 20; else
		if(DDRAM_address<0x40) DDRAM_address = 0x40;	else
		if(DDRAM_address<0x40+20) DDRAM_address = 0x40+20;	else
		if(DDRAM_address>=0x40+20) DDRAM_address = 0;
	} else {
		lcd_set_type_data();
		lcd_write_byte(c);
	}
	char save_char;
	int ic=0;
	int ir=1;
	switch(DDRAM_address){
		case 20: lcd_goto_position(1,0); break;
		case 0x40+20: lcd_goto_position(2,0); break;
		case 0x40: lcd_goto_position(3,0); break;
		case 0: // scroll up
			for(ic=0;ic<CHARS;ic++){
				for(ir=1;ir<LINES;ir++){
					lcd_goto_position(ir,ic);
					lcd_set_type_data();
					save_char = lcd_read_byte();
					lcd_goto_position(ir-1,ic);
					lcd_set_type_data();
					lcd_write_byte(save_char);
				}
			}
			lcd_goto_position(3,0);
			for(ic=0;ic<CHARS;ic++){
				lcd_set_type_data();
				lcd_write_byte(' ');
			}
			lcd_goto_position(3,0);
			break;
	}
	#endif
#endif
}

void lcd_goto_position(uint8_t row, uint8_t col){
	// 20x4 LCD: offsets 0, 0x40, 20, 0x40+20
	volatile uint8_t row_offset = 0;
	switch(row){
		case 0: row_offset = 0; break;
		case 1: row_offset = 0x40; break;
		case 2: row_offset = 20; break;
		case 3: row_offset = 0x40+20; break;
	}
	lcd_set_type_command();
	lcd_write_byte(0x80 | (row_offset + col));
}

void lcd_line_one()		{ lcd_goto_position(0, 0); }
void lcd_line_two()		{ lcd_goto_position(1, 0); }
void lcd_line_three()	{ lcd_goto_position(2, 0); }
void lcd_line_four()	{ lcd_goto_position(3, 0); }

void lcd_init(){
	// set pin driver directions
	OUTPUT(LCD_RS);		CLEAR(LCD_RS);
	OUTPUT(LCD_E);		CLEAR(LCD_E);
	#ifdef LCD_RW
		OUTPUT(LCD_RW); CLEAR(LCD_RW);// optional for using ready/busy flag
																	// must be tied to gnd if not used here
	#endif
	lcd_set_data_pins_output();

	// wait 100msec
	_delay_ms(100);
	lcd_set_type_command();

	// do reset
	lcd_write_nibble(0x03);
	_delay_ms(6);
	lcd_write_nibble(0x03);
	_delay_us(250);
	lcd_write_nibble(0x03);
//	_delay_us(250);
  
	// write 0010 (data length 4 bits)
	lcd_write_nibble(0x02);
	_delay_us(50);
	// set to 2 lines, font 5x8
	lcd_write_byte(0x28);
	_delay_us(50);
	// enable LCD
	lcd_write_byte(0x0c);
	_delay_us(50);
	// set entry mode
	lcd_write_byte(0x06);
	_delay_us(50);

	// set cursor/display shift
	lcd_write_byte(0x14);
	_delay_us(50);

	// clear and home
	lcd_clear_and_home();
}

int lcd_putchar(char c, FILE *stream){
	lcd_write_data(c);
	return 0;
}

#endif
