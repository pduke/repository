#ifndef __JSON_UTILITY
	#define __JSON_UTILITY
	// JSON functions, definitions, and variables for communication
	// with JAC (JSON Automation Console). Each JSON object, sent
	// or received, is terminated with a newline character.
	// Examples are used in this program.
	//
	// <-- JSON sent to JAC to for console display.
	// --> JSON received from JAC typcally from user interaction.
	//
//
// functions and variables to handle serial I/O
//
// file streams and helper macros for lcd and serial port
FILE lcd_stream;
bool LCD_Enabled = true;
#define lprintf(...) if(LCD_Enabled)fprintf(&lcd_stream, __VA_ARGS__);
#define lprintf_P(...) if(LCD_Enabled)fprintf_P(&lcd_stream, __VA_ARGS__);
FILE uart_stream;
#define uprintf(...) fprintf(&uart_stream, __VA_ARGS__);	flush_serial();
#define uprintf_P(...) fprintf_P(&uart_stream, __VA_ARGS__);flush_serial();
//
// define ring buffers for serial data
#define Q_SIZE 32		// must be power of 2
#define Q_MASK Q_SIZE-1
volatile uint8_t r_buff[Q_SIZE];
volatile uint8_t r_in = 0;
volatile uint8_t r_out = 0;
volatile uint8_t w_buff[Q_SIZE];
volatile uint8_t w_in = 0;
volatile uint8_t w_out = 0;
//
// write byte to serial port
void uart_writeB(char data) {
	while ((UCSR0A & (1<<UDRE0))==0);	// wait for empty transmit buffer
	UDR0 = data;	// send
}
//
// empty write buffer
void flush_serial(void){
	while (w_out != w_in){
		uart_writeB(w_buff[w_out++]);
		w_out &= Q_MASK;
	}
}
//
// write to buffer
void write_serial(char data){
	w_buff[w_in++] = data;
	w_in &= Q_MASK;
	if(w_in == w_out){
		uart_writeB(w_buff[w_out++]);
		w_out &= Q_MASK;
	}
}
//
// support stdio stream
int uart_fputchar(char data, FILE *stream) {
	write_serial(data);
	return 0;
}
//
// UART received data interrupt routine
// will put incoming character into ring buffer
ISR(USART_RX_vect, ISR_BLOCK){
	r_buff[r_in++] = UDR0;								// store character
	r_in &= Q_MASK;												// wrap pointer if end
}
//
// initialize serial I/O
void serial_init(){
  // enable uart RX and TX
  UCSR0B = (1<<RXEN0)|(1<<TXEN0);
  // set 8N1 frame format
  UCSR0C = (1<<UCSZ01)|(1<<UCSZ00);
  // set baud rate
  UBRR0H = 0;
	UCSR0A = 0;
	UBRR0L = (F_CPU/(16*BAUD))-1;	// F_CPU & BAUD defined in makefile
	UCSR0B |= _BV(RXCIE0);
	// setup uart stream
	fdev_setup_stream(&uart_stream, uart_fputchar, 0, _FDEV_SETUP_WRITE); 
}

	// EXE identifies the command operand for JAC
	#define strEXE PSTR("EXE")
	//
	// Must be able to hold the longest JSON object string
	#define JSON_OBJECT_BUFFER_LENGTH 70
	//
	// blank will clear the console screen.
	// <-- {"EXE":"BLANK"}
	#define strBLANK PSTR("BLANK")
	//
	// get the current date and time.
	// <-- {"EXE":"DATETIME"} use default timezone
	// <-- {"EXE":"DATETIME", "TIMEZONE":"US/CENTRAL"}
	// --> {"EXE":"DATETIME", "DATETIME":"yyyy-MM-dd hh:mm:ss"}
	#define strDATETIME PSTR("DATETIME")
	#define strTIMEZONE PSTR("TIMEZONE")
	//
	// JAC requests redraw of the console screen as needed
	// --> {"EXE":"SCREEN"}
	#define strSCREEN PSTR("SCREEN")
	//
	// Toast is used to tell JAC to display a popup message
	// <-- {"EXE":"TOAST", "TEXT":"This is a sample message."}
	#define strTOAST PSTR("TOAST")
	#define strTEXT PSTR("TEXT")
	//
	// Add some vertical space between screen elements, height in pixels
	// <-- {"EXE":"ADDSPACE", "HEIGHT":"10"}
	#define strADDSPACE PSTR("ADDSPACE")
	#define strHEIGHT PSTR("HEIGHT")
	//
	// Add vertical space but fill to create a line
	// <-- {"EXE":"ADDLINE", "HEIGHT":"5"}
	#define strADDLINE PSTR("ADDLINE")
	#define strHEIGHT PSTR("HEIGHT")
	//
	// Simply advance to the next line
	// <-- {"EXE":"NEWLINE"}
	#define strNEWLINE PSTR("NEWLINE")
	//
	// Add/set text for title or value
	// <-- {"EXE":"ADDTEXT", "TEXT":"JAC Demo", "GRAVITY":"CENTER",
	//				"WEIGHT":"1.0", "SIZE":"LARGE", "ID":"100"}
	#define strADDTEXT PSTR("ADDTEXT")
	#define strTEXT PSTR("TEXT")
	#define strGRAVITY PSTR("GRAVITY")	// alignment
	#define			strLEFT PSTR("LEFT")
	#define			strCENTER PSTR("CENTER")
	#define			strRIGHT PSTR("RIGHT")
	#define strWEIGHT PSTR("WEIGHT")		// requested column width as percent/100
	#define strSIZE PSTR("SIZE")					// relative font size
	#define			strSMALL PSTR("SMALL")
	#define			strMEDIUM PSTR("MEDIUM")
	#define			strLARGE PSTR("LARGE")
	//
	// Add an ON/OFF switch
	// <-- {"EXE":"ADDSWITCH", "ID":"1", "TEXT":"", "GRAVITY":"RIGHT",
	//				"WEIGHT":"0.0", "SIZE":"LARGE", "STATE":"OFF"}
	#define strADDSWITCH PSTR("ADDSWITCH")
	#define strID PSTR("ID")						// must uniquely identify each interactive element
	#define strTEXT PSTR("TEXT")
	#define strGRAVITY PSTR("GRAVITY")
	#define			strLEFT PSTR("LEFT")
	#define			strCENTER PSTR("CENTER")
	#define			strRIGHT PSTR("RIGHT")
	#define strWEIGHT PSTR("WEIGHT")
	#define strSIZE PSTR("SIZE")	
	#define			strSMALL PSTR("SMALL")
	#define			strMEDIUM PSTR("MEDIUM")
	#define			strLARGE PSTR("LARGE")
	#define strSTATE PSTR("STATE")
	#define			strON PSTR("ON")
	#define			strOFF PSTR("OFF")
	//
	// JSON object received when switch is toggled by user
	// --> {"EXE":"ACTION", "ID":"1", "STATE":"ON"}
	#define strACTION PSTR("ACTION")
	#define strID PSTR("ID")
	#define strSTATE PSTR("STATE")
	#define			strON PSTR("ON")
	#define			strOFF PSTR("OFF")
	//
	// Add a CheckBox
	// <-- {"EXE":"ADDCHECK", "ID":"2", "TEXT":"", "GRAVITY":"RIGHT",
	//				"WEIGHT":"0.0", "SIZE":"LARGE", "CHECKED":"NO"}
	#define strADDCHECK PSTR("ADDCHECK")
	#define strID PSTR("ID")
	#define strTEXT PSTR("TEXT")
	#define strGRAVITY PSTR("GRAVITY")
	#define			strLEFT PSTR("LEFT")
	#define			strCENTER PSTR("CENTER")
	#define			strRIGHT PSTR("RIGHT")
	#define strWEIGHT PSTR("WEIGHT")
	#define strSIZE PSTR("SIZE")	
	#define			strSMALL PSTR("SMALL")
	#define			strMEDIUM PSTR("MEDIUM")
	#define			strLARGE PSTR("LARGE")
	#define strCHECKED PSTR("CHECKED")
	#define			strYES PSTR("YES")
	#define			strNO PSTR("NO")
	//
	// JSON object returned when checked by user
	// --> {"EXE":"ACTION", "ID":"2", "CHECKED":"YES"}
	#define strACTION PSTR("ACTION")
	#define strID PSTR("ID")
	#define strCHECKED PSTR("CHECKED")
	#define			strYES PSTR("YES")
	#define			strNO PSTR("NO")
	///
	// Add a single line EditText field
	// <-- {"EXE":"ADDEDIT", "ID":"3", "TEXT":"10", "GRAVITY":"RIGHT",
	//				"WEIGHT":"0.0", "SIZE":"LARGE", "LENGTH":"3", "TYPE":"INTEGER"}
	#define strADDEDIT PSTR("ADDEDIT")
	#define strID PSTR("ID")
	#define strTEXT PSTR("TEXT")
	#define strGRAVITY PSTR("GRAVITY")
	#define			strLEFT PSTR("LEFT")
	#define			strCENTER PSTR("CENTER")
	#define			strRIGHT PSTR("RIGHT")
	#define strWEIGHT PSTR("WEIGHT")
	#define strSIZE PSTR("SIZE")	
	#define			strSMALL PSTR("SMALL")
	#define			strMEDIUM PSTR("MEDIUM")
	#define			strLARGE PSTR("LARGE")
	#define strLENGTH PSTR("LENGTH") // max length in charJSON_IN_BUFFER_LENGTHacters
	#define strTYPE PSTR("TYPE")		// specifies type of text allowed
	#define			strTEXT_NORMAL PSTR("TEXT_NORMAL")
	#define			strTEXT_UPPER PSTR("TEXT_UPPER")
	#define			strINTEGER PSTR("INTEGER")
	#define			strSIGNED_INTEGER PSTR("SIGNED_INTEGER")
	#define			strDECIMAL PSTR("DECIMAL")
	#define			strSIGNED_DECIMAL PSTR("SIGNED_DECIMAL")
	//
	// get the text from an EditText field
	// <-- {"EXE":"GETEDIT", "ID":"3"}
	#define strGETEDIT PSTR("GETEDIT")
	#define strID PSTR("ID")
	//
	// replace text in an EditText field
	// <-- {"EXE":"SETEDIT", "ID":"3", "TEXT":"1"}
	#define strSETEDIT PSTR("SETEDIT")
	#define strID PSTR("ID")
	#define strTEXT PSTR("TEXT")
	//
	// replace text in a regular text field that was added with a non-zero id
	#define strSETTEXT PSTR("SETTEXT")
	#define strID PSTR("ID")
	#define strTEXT PSTR("TEXT")
	//
	// Text is not automatically sent by JAC while
	// user is entering new values. Best to use a button
	// user can click when done entering value(s) and then
	// get the text as above and wait for reciept of 
	// JSON object with new value. The following is 
	// returned by JAC after a GETEDIT request.
	// --> {"EXE":"ACTION", "ID":"3", "TEXT":"11"}
	#define strACTION PSTR("ACTION")
	#define strID PSTR("ID")
	#define strTEXT PSTR("TEXT")
	//
	// Add a Button
	// <-- {"EXE":"ADDBUTTON", "ID":"4", "TEXT":"SET", "WEIGHT":"0.0", "SIZE":"SMALL"}
	#define strADDBUTTON PSTR("ADDBUTTON")
	#define strID PSTR("ID")
	#define strTEXT PSTR("TEXT")
	#define strWEIGHT PSTR("WEIGHT")
	#define strSIZE PSTR("SIZE")	
	#define			strSMALL PSTR("SMALL")
	#define			strMEDIUM PSTR("MEDIUM")
	#define			strLARGE PSTR("LARGE")
	//
	// JSON object returned when button clicked by user
	// --> {"EXE":"ACTION", "ID":"4", "CLICKED":"YES"}
	#define strACTION PSTR("ACTION")
	#define strID PSTR("ID")
	#define strCLICKED PSTR("CLICKED")
	#define			strYES PSTR("YES")
	#define			strNO PSTR("NO")
	//
	// Add a Spinner
	// <-- {"EXE":"ADDSPINNER", "ID":"4", "GRAVITY":"RIGHT", "WEIGHT":"1", "SIZE":"SMALL"}
	#define strADDSPINNER PSTR("ADDSPINNER")
	#define strID PSTR("ID")
	#define strGRAVITY PSTR("GRAVITY")
	#define			strLEFT PSTR("LEFT")
	#define			strCENTER PSTR("CENTER")
	#define			strRIGHT PSTR("RIGHT")
	#define strWEIGHT PSTR("WEIGHT")
	#define strSIZE PSTR("SIZE")	
	#define			strSMALL PSTR("SMALL")
	#define			strMEDIUM PSTR("MEDIUM")
	#define			strLARGE PSTR("LARGE")
	//
	// Add a list item to a spinner
	// <-- {"EXE":"ADDSPINNERTEXT", "ID":"4", "TEXT":"1 Min"}
	#define strADDSPINNERTEXT PSTR("ADDSPINNERTEXT")
	#define strID PSTR("ID")
	#define strTEXT PSTR("TEXT")
	//
	// Select list item in a spinner via index
	// <-- {"EXE":"SELECTSPINNERINDEX", "ID":"4", "INDEX":"2"}
	#define strSELECTSPINNERINDEX PSTR("SELECTSPINNERINDEX")
	#define strID PSTR("ID")
	#define strINDEX PSTR("INDEX")
	//
	// Select list item in a spinner via text
	// <-- {"EXE":"SELECTSPINNERTEXT", "ID":"4", "TEXT":"CENTRAL"}
	#define strSELECTSPINNERTEXT PSTR("SELECTSPINNERTEXT")
	#define strID PSTR("ID")
	#define strTEXT PSTR("TEXT")
	//
	// add all known timezones to a spinner
	// <-- {"EXE":"SPINNERGETTIMEZONES", "ID":"4",}
	#define strSPINNERGETTIMEZONES PSTR("SPINNERGETTIMEZONES")
	#define strID PSTR("ID")
	//
	// JSON object returned when spinner item selected by user
	// --> {"EXE":"ACTION", "ID":"4", "POSITION":"2"}
	#define strACTION PSTR("ACTION")
	#define strID PSTR("ID")
	#define strPOSITION PSTR("POSITION")
	//
	// Get spinner selected text
	// <-- {"EXE":"SPINNERGETTEXT", "ID":"4"}
	// --> {"EXE":"SPINNERGETTEXT", "TEXT":"CENTRAL"}
	#define strSPINNERGETTEXT PSTR("SPINNERGETTEXT")
	#define strID PSTR("ID")
	#define strTEXT PSTR("TEXT")
	//
	// Add a SeekBar
	// <-- {"EXE":"ADDSEEK", "ID":"5", "WEIGHT":"1.0", "LEVEL":"16", "MAX":"50"}
	#define strADDSEEK PSTR("ADDSEEK")
	#define strID PSTR("ID")
	#define strWEIGHT PSTR("WEIGHT")
	#define strLEVEL PSTR("LEVEL")
	#define strMAX PSTR("MAX")
	//
	// set the current level for a SeekBar
	// <-- {"EXE":"SETSEEK", "ID":"5", "LEVEL":"1"}
	#define strSETSEEK PSTR("SETSEEK")
	#define strID PSTR("ID")
	#define strLEVEL PSTR("LEVEL")
	//
	// get the current level from a SeekBar
	// <-- {"EXE":"GETSEEK", "ID":"5"}
	#define strGETSEEK PSTR("GETSEEK")
	#define strID PSTR("ID")
	// JSON object returned from SeekBar when moved by user or GETSEEK
	// --> {"EXE":"ACTION", "ID":"5", "CLICKED":"YES"}
	#define strACTION PSTR("ACTION")
	#define strID PSTR("ID")
	#define strLEVEL PSTR("LEVEL")
	//
	// Begin a group of radio buttons
	// --> {"EXE":"RADIOGROUP", "ORIENTATION":"HORIZONTAL"}
	#define strRADIOGROUP PSTR("RADIOGROUP")
	#define strORIENTATION PSTR("ORIENTATION")
	#define			strHORIZONTAL PSTR("HORIZONTAL")
	#define			strVERTICAL PSTR("VERTICAL")
	//
	// Add a RadioButton to the group
	// <-- {"EXE":"ADDRADIOBUTTON", "ID":"10", "TEXT":"Red",
	//				"WEIGHT":"0.25", "SIZE":"MEDIUM", "SELECTED":"NO"}
	#define strADDRADIOBUTTON PSTR("ADDRADIOBUTTON")
	#define strID PSTR("ID")
	#define strTEXT PSTR("TEXT")
	#define strWEIGHT PSTR("WEIGHT")
	#define strSIZE PSTR("SIZE")	
	#define			strSMALL PSTR("SMALL")
	#define			strMEDIUM PSTR("MEDIUM")
	#define			strLARGE PSTR("LARGE")
	#define strSELECTED PSTR("SELECTED")
	#define			strYES PSTR("YES")
	#define			strNO PSTR("NO")
	//
	// JSON object returned when RadioButton selected by user
	// --> {"EXE":"ACTION", "ID":"10", "CHECKED":"YES"}
	#define strACTION PSTR("ACTION")
	#define strID PSTR("ID")
	#define strSELECTED PSTR("SELECTED")
	#define			strYES PSTR("YES")
	#define			strNO PSTR("NO")
	//
	// null string for text fields
	#define strNULL_TEXT PSTR("")
	//
	// JSON outbound object buffer, must be large enough to hold entire object string
	char json_string[JSON_OBJECT_BUFFER_LENGTH];
	//
	// helper for JSMN, put string terminators in buffer
	void jsMakeStrings(jsmntok_t *jt, char *jsonBuffer){
		int i = 0;
		while(jt[i++].type){
			jsonBuffer[jt[i].end]=0x00;	// null terminator at end of string
		}
	}
	//
	// helper for JSMN, given name return value for JSON pair
	char *jsGetValue_P(char *jsonBuffer, jsmntok_t *jt, PGM_P name){
		int i = 1;
		while(jt[i].type){
			if(strcmp_P(&jsonBuffer[jt[i].start], name)==0){
				break;
			}
			i+=2;
		}
		return(&jsonBuffer[jt[i+1].start]);
	}
	//
	// helper for JSMN, initialize token array
	void jsmn_token_init(jsmntok_t* jt, int length){
		for(int j=0;j<length;j++){										// init jsmn token array
		jt[j].type=0;
		jt[j].start=0;
		jt[j].end=0;
		}
	}
	//
	// JSON object builder utility routines
	// 
	// opening JSON pair, first pair in object
	void json_pair_first(PGM_P name, PGM_P value){
		uprintf_P(PSTR("{"));
		uprintf_P(PSTR("\"%s\""), strcpy_P(json_string, name));
		uprintf_P(PSTR(":"));
		uprintf_P(PSTR("\"%s\""), strcpy_P(json_string, value));
	}
	//
	// add pair with flash string value
	void json_pair_nexts(PGM_P name, PGM_P value){
		uprintf_P(PSTR(","));
		uprintf_P(PSTR("\"%s\""), strcpy_P(json_string, name));
		uprintf_P(PSTR(":"));
		uprintf_P(PSTR("\"%s\""), strcpy_P(json_string, value));
	}
	//
	// add pair with ram string value
	void json_pair_nextsc(PGM_P name, char* value){
		uprintf_P(PSTR(","));
		uprintf_P(PSTR("\"%s\""), strcpy_P(json_string, name));
		uprintf_P(PSTR(":"));
		uprintf_P(PSTR("\"%s\""), value);
	}
	//
	// add pair with ram integer value
	void json_pair_nexti(PGM_P name, uint16_t value){
		uprintf_P(PSTR(","));
		uprintf_P(PSTR("\"%s\""), strcpy_P(json_string, name));
		uprintf_P(PSTR(":"));
		uprintf_P(PSTR("\"%d\""), value);
	}
	//
	// add pair with ram float value
	void json_pair_nextf(PGM_P name, double value){
		uprintf_P(PSTR(","));
		uprintf_P(PSTR("\"%s\""), strcpy_P(json_string, name));
		uprintf_P(PSTR(":"));
		uprintf_P(PSTR("\"%0.2f\""), value);
	}
	//
	// end the JSON object and add newline terminator
	void json_end(){
		uprintf_P(PSTR("}\n"));
	}
	//
	// JSON functions for each JAC element
	//
	// blank the JAC screen
	void jacBlank(){
		json_pair_first(strEXE, strBLANK);json_end();
	}
	// request date and time from the host
	void jacGetDateTime(){
		json_pair_first(strEXE, strDATETIME);json_end();
	}
	// Add title or label text
	void jacAddText(PGM_P text, PGM_P gravity, double weight, PGM_P size){
		json_pair_first(strEXE, strADDTEXT);
		json_pair_nexts(strTEXT, text);
		json_pair_nexts(strGRAVITY, gravity);
		json_pair_nextf(strWEIGHT, weight);
		json_pair_nexts(strSIZE, size);
		json_end();
	}
	//
	// Add text from char* with ID
	void jacAddCharStringId(char* text, PGM_P gravity, double weight, PGM_P size, uint8_t id){
		json_pair_first(strEXE, strADDTEXT);
		json_pair_nextsc(strTEXT, text);
		json_pair_nexts(strGRAVITY, gravity);
		json_pair_nextf(strWEIGHT, weight);
		json_pair_nexts(strSIZE, size);
		if(id!=0){
			json_pair_nexti(strID, id);  
		}
		json_end(); 
	}
	//
	// Add text from char*
	void jacAddCharString(char* text, PGM_P gravity, double weight, PGM_P size){
		jacAddCharStringId(text, gravity, weight, size, 0);
	}
	//
	// set new value into char* text with id
	void jacSetCharString(int id, char* text){
		json_pair_first(strEXE, strSETTEXT);
		json_pair_nexti(strID, id);
		json_pair_nextsc(strTEXT, text);
		json_end();
	}
	//
	// Add vertical space n pixels in height
	void jacAddVerticalSpace(int pixelHeight){
		json_pair_first(strEXE, strADDSPACE);
		json_pair_nexti(strHEIGHT, pixelHeight);
		json_end();
	}
	//
	// Add a divider line, same as vertical space but colored background
	void jacAddDividerLine(int pixelHeight){
		json_pair_first(strEXE, strADDLINE);
		json_pair_nexti(strHEIGHT, pixelHeight);
		json_end();
	}
	//
	// Simply move cursor to next line on JAC console
	void jacAddNewLine(){
		json_pair_first(strEXE, strNEWLINE);
		json_end();
	}
	//
	// Add an ON/OFF switch
	void 	jacAddSwitch(int id, PGM_P text, PGM_P gravity, double weight, PGM_P size, bool state){
		json_pair_first(strEXE, strADDSWITCH);
		json_pair_nexti(strID, id);
		json_pair_nexts(strTEXT, text);
		json_pair_nexts(strGRAVITY, gravity);
		json_pair_nextf(strWEIGHT, weight);
		json_pair_nexts(strSIZE, size);
		json_pair_nexts(strSTATE, state?strON:strOFF);
		json_end();
	}
	//
	// Add a check box
	void 	jacAddCheck(int id, PGM_P text, PGM_P gravity, double weight, PGM_P size, bool state){
		json_pair_first(strEXE, strADDCHECK);
		json_pair_nexti(strID, id);
		json_pair_nexts(strTEXT, text);
		json_pair_nexts(strGRAVITY, gravity);
		json_pair_nextf(strWEIGHT, weight);
		json_pair_nexts(strSIZE, size);
		json_pair_nexts(strCHECKED, state?strYES:strNO);
		json_end();
	}
	//
	// Add a single line EditText field
	void 	jacAddEditText(int id, char* text, PGM_P gravity, double weight,
											PGM_P size, int length, PGM_P textType){
		json_pair_first(strEXE, strADDEDIT);
		json_pair_nexti(strID, id);
		json_pair_nextsc(strTEXT, text);
		json_pair_nexts(strGRAVITY, gravity);
		json_pair_nextf(strWEIGHT, weight);
		json_pair_nexts(strSIZE, size);
		json_pair_nexti(strLENGTH, length);
		json_pair_nexts(strTYPE, textType);
		json_end();
	}
	//
	// retrieve the value of an EditText field
	void getEditText(int id){
		json_pair_first(strEXE, strGETEDIT);
		json_pair_nexti(strID, id);
		json_end();
	}
	//
	// set new value into an EditText field
	void setEditText(int id, int value){
		json_pair_first(strEXE, strSETEDIT);
		json_pair_nexti(strID, id);
		json_pair_nexti(strTEXT, value);
		json_end();
	}
	//
	// Add a simple button
	void 	jacAddButton(int id, PGM_P text, double weight, PGM_P size){
		json_pair_first(strEXE, strADDBUTTON);
		json_pair_nexti(strID, id);
		json_pair_nexts(strTEXT, text);
		json_pair_nextf(strWEIGHT, weight);
		json_pair_nexts(strSIZE, size);
		json_end();
	}
	//
	// Add a spinner
	void 	jacAddSpinner(int id, PGM_P gravity, double weight, PGM_P size){
		json_pair_first(strEXE, strADDSPINNER);
		json_pair_nexti(strID, id);
		json_pair_nexts(strGRAVITY, gravity);
		json_pair_nextf(strWEIGHT, weight);
		json_pair_nexts(strSIZE, size);
		json_end();
	}
	//
	// Add a list item to a spinner
	void 	jacAddSpinnerText(int id, PGM_P text){
		json_pair_first(strEXE, strADDSPINNERTEXT);
		json_pair_nexti(strID, id);
		json_pair_nexts(strTEXT, text);
		json_end();
	}	
	//
	// Select list item in a spinner by index
	void 	jacSelectSpinnerIndex(int id, int index){
		json_pair_first(strEXE, strSELECTSPINNERINDEX);
		json_pair_nexti(strID, id);
		json_pair_nexti(strINDEX, index);
		json_end();
	}	
	//
	// Select list item in a spinner with matching text
	void 	jacSelectSpinnerText(int id, char* text){
		json_pair_first(strEXE, strSELECTSPINNERTEXT);
		json_pair_nexti(strID, id);
		json_pair_nextsc(strTEXT, text);
		json_end();
	}
	//
	// Retrieve spinner selected text
	void  jacSpinnerGetText(int id){
		json_pair_first(strEXE, strSPINNERGETTEXT);
		json_pair_nexti(strID, id);
		json_end();
	}

	//
	// Add known timezones to a spinner
	void 	jacSpinnerAddTimezonesText(int id){
		json_pair_first(strEXE, strSPINNERGETTIMEZONES);
		json_pair_nexti(strID, id);
		json_end();
	}

	//
	// Add a seek bar
	void 	jacAddSeekBar(int id, int level, int max, double weight){
		json_pair_first(strEXE, strADDSEEK);
		json_pair_nexti(strID, id);
		json_pair_nexti(strLEVEL, level);
		json_pair_nexti(strMAX, max);
		json_pair_nextf(strWEIGHT, weight);
		json_end();
	}
	//
	// retrieve the current level of a seek bar
	void getSeekLevel(int id){
		json_pair_first(strEXE, strGETSEEK);
		json_pair_nexti(strID, id);
		json_end();
	}
	//
	// set a new level for a seek bar
	void setSeekLevel(int id, int value){
		json_pair_first(strEXE, strSETSEEK);
		json_pair_nexti(strID, id);
		json_pair_nexti(strLEVEL, value);
		json_end();
	}
	//
	// start a radio button group
	void addRadioGroup(PGM_P orientation){
		json_pair_first(strEXE, strRADIOGROUP);
		json_pair_nexts(strORIENTATION, orientation);
		json_end();
	}
	//
	// Add a RadioButton to the current group
	void 	jacAddRadioButton(int id, PGM_P text, double weight, PGM_P size, bool state){
		json_pair_first(strEXE, strADDRADIOBUTTON);
		json_pair_nexti(strID, id);
		json_pair_nexts(strTEXT, text);
		json_pair_nextf(strWEIGHT, weight);
		json_pair_nexts(strSIZE, size);
		json_pair_nexts(strSELECTED, state?strYES:strNO);
		json_end();
	}
	//
	// Display a pop up message on the screen from flash string
	void Toast_P(PGM_P msg){
		json_pair_first(strEXE, strTOAST);
		json_pair_nexts(strTEXT, msg);
		json_end();
	}
	//
	// Display a pop up message on the screen from ram string
	void Toast(char* msg){
		json_pair_first(strEXE, strTOAST);
		json_pair_nextsc(strTEXT, msg);
		json_end();
	}
	//
	//
	// End of JSON routines
	//
#endif

