//
// NOTER_AVR_messages.c
//
//	v1.1  3/24/2011
// 
// Common message functions used between the AVR and NOTER_AVRserv on the host PC
//

#include "../libNoter/NOTER_AVR_messages.h"


int PutCommChar(unsigned char chrOut);
int GetCommChar(unsigned char *chrIn);


void init_msg(){
	p_msg_wrap		= (MSG_WRAP*)msg_buff;
	p_put_time_msg	= (PUT_TIME_MSG*)p_msg_wrap->msg_cmd_data;
}

unsigned char make_crc(unsigned char *data, int length){
	unsigned char	tmp_crc;
	int i;
	tmp_crc = 0;
	for(i=0;i<length;i++){
		tmp_crc ^= data[i];
	}
	return(tmp_crc);
}

int send_msg(unsigned char *buffer, unsigned char length){
	unsigned char i;
	for(i=0;i<length;i++){
		if(PutCommChar(buffer[i])){
			return 1;
		}
	}
	return(0);
}

int get_msg(){
	int i;
	unsigned char msg_crc;
	*msg_buff=0x00;
	while(1){
		if(GetCommChar(msg_buff)==0){
			if(msg_buff[0]==MSG_ESC){
				
				if(GetCommChar(&msg_buff[1])>0){ // 2nd byte is message length
					return(1);
				} else {
					for(i=2;i<p_msg_wrap->msg_len;i++){
						if(GetCommChar(&msg_buff[i])>0){
							return(2);
						}
					}
					msg_crc = p_msg_wrap->msg_crc;
					p_msg_wrap->msg_crc = 0;
					if(msg_crc != make_crc(msg_buff, p_msg_wrap->msg_len)){
						return(3);
					} else {
						break;
					}
				}
			}
		}
	}
	return(0);
}
