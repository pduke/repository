// _7seg_display.h
// 
// Define all message formats, buffers, and functions for communicating with the slave display
//

// command codes for display driver messages
#define v_7seg_display_int_cmd 0x01
#define v_7seg_display_dbl_cmd 0x02
#define v_7seg_invoke_pattern_cmd 0x03
#define v_7seg_set_blink_cmd 0x04
#define v_7seg_display_hex_cmd 0x05
#define v_7seg_specific_segs_cmd 0x06
#define v_7seg_set_brightness_cmd 0x07
#define v_7seg_get_info_cmd 0x08
#define v_7seg_info_reply_cmd 0x09
#define v_7seg_display_time_cmd 0x10

// slave message formats
typedef struct {
	uint8_t command;
} _7seg_display_cmd;

typedef struct {
	uint8_t command; //0x01
	uint16_t int_value;
	uint8_t colon_on; // one bit for each colon
	uint8_t apostrophe_on; // one bit for each apostrophe
} _7seg_display_int_msg;

typedef struct {
	uint8_t command; //0x02
	double dbl_value;
	uint8_t colon_on; // one bit for each colon
	uint8_t apostrophe_on; // one bit for each apostrophe
} _7seg_display_dbl_msg;

typedef struct {
	uint8_t command; //0x03
	uint16_t cycle_ms; // on/off time for pattern
	uint8_t pattern; // 0-off, 1-random, 2-waterfall, 3-roundabout
} _7seg_invoke_pattern_msg;

typedef struct {
	uint8_t command; //0x04
	uint8_t blink_state; // 0-off, 1-on
	uint16_t cycle_ms; // on/off time for blink
} _7seg_set_blink_msg;

typedef struct {
	uint8_t command; //0x05
	uint16_t hex_value;
	uint8_t colon_on; // one bit for each colon
	uint8_t apostrophe_on; // one bit for each apostrophe
} _7seg_display_hex_msg;

typedef struct {
	uint8_t command; //0x06
	uint8_t colon_on; // one bit for each colon
	uint8_t apostrophe_on; // one bit for each apostrophe
	uint8_t segs[]; // 8 bits for 8 segs of each digit
} _7seg_specific_segs_msg;

typedef struct {
	uint8_t command; //0x07
	uint8_t brightness; // 0-min, 255-max
} _7seg_set_brightness_msg;

typedef struct {
	uint8_t command; //0x08
} _7seg_get_info_msg;

typedef struct {
	uint8_t command; //0x09
	uint8_t digit_count; // number of 7 seg digits in my display
	uint8_t decimal_point_count; 
	uint8_t colon_count;
	uint8_t apostrophe_count;
} _7seg_info_reply;

typedef struct {
	uint8_t command; //0x10
	uint8_t hour; 
	uint8_t minute; 
	uint8_t second;
} _7seg_display_time_msg;

// buffer used for I2C communications
uint8_t TWI_buffer[20];

// display driver message buffer pointers
volatile _7seg_display_cmd *p_7seg_display_cmd;
volatile _7seg_display_int_msg *p_7seg_display_int_msg;
volatile _7seg_display_dbl_msg *p_7seg_display_dbl_msg;
volatile _7seg_invoke_pattern_msg *p_7seg_invoke_pattern_msg;
volatile _7seg_set_blink_msg *p_7seg_set_blink_msg;
volatile _7seg_display_hex_msg *p_7seg_display_hex_msg;
volatile _7seg_specific_segs_msg *p_7seg_specific_segs_msg;
volatile _7seg_set_brightness_msg *p_7seg_set_brightness_msg;
volatile _7seg_get_info_msg *p_7seg_get_info_msg;
volatile _7seg_info_reply *p_7seg_info_reply;
volatile _7seg_display_time_msg *p_7seg_display_time_msg;

// display driver functions
void _7seg_init(uint32_t f_cpu, uint32_t i2c_bitrate, void (*I2C_callback)(volatile uint8_t TWI_match_addr, uint8_t return_code));
void _7seg_display_hex(uint8_t slave_addr, int16_t hex_value, uint8_t colon, uint8_t apostrophe);
void _7seg_display_int(uint8_t slave_addr, int16_t int_value, uint8_t colon, uint8_t apostrophe);
void _7seg_display_dbl(uint8_t slave_addr, double dbl_value, uint8_t colon, uint8_t apostrophe);
void _7seg_set_blink(uint8_t slave_addr, uint8_t blink_on, uint16_t ms_cycle);
void _7seg_invoke_pattern(uint8_t slave_addr, uint8_t pattern, uint16_t ms_cycle);
void _7seg_light_segments(uint8_t slave_addr, uint8_t num_digits, uint8_t *digits, uint8_t colon, uint8_t apostrophe);
void _7seg_set_brightness(uint8_t slave_addr, uint8_t brightness);
void _7seg_get_display_info(uint8_t slave_addr, uint8_t *digits, uint8_t *decimals, uint8_t *colons, uint8_t *apostrophes);
void _7seg_display_time(uint8_t slave_addr, uint8_t hour, uint8_t minute, uint8_t second);

