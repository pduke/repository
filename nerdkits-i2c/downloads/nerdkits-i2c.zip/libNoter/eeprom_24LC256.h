
void init_24LC256(long cpu_freq, long bit_rate, uint16_t buffer_size, uint8_t device_count, uint16_t device_addresses[]);
void read_24LC256(uint16_t address, void *data, uint16_t size);
void write_24LC256(uint16_t address, void *data, uint16_t size);









