//
// RS232.c
// 
// provide serial comm via uart
//
//

#include <avr/interrupt.h>
#include <stdbool.h>
#include "../libNoter/NOTER_AVR_messages.h"
#include "../libNoter/RS232.h"

int				(*RS232_process_msg)();
unsigned char	RS232_buffer_pos;
unsigned char	RS232_msg_len;
unsigned char	RS232_msg_crc;
bool			RS232_msg_started;

void init_RS232(uint32_t f_cpu, uint32_t baud_rate, int (*call_back)()) {
	RS232_process_msg = call_back;
	init_msg();
	// set baud rate
	switch(baud_rate){ // see page 199 -200 in ATmega328 spec
		case 115200L:
			switch(f_cpu){
				case 7372800L:
					UCSR0A = 0;
					UBRR0H = 0;
					UBRR0L = 3;	
					break;
				case 8000000L:
					UCSR0A = _BV(U2X0);
					UBRR0H = 0;
					UBRR0L = 8;	
					break;
				case 14745600L:
					UCSR0A = 0;
					UBRR0H = 0;
					UBRR0L = 7;	
					break;
				case 18432000L:
					UCSR0A = 0;
					UBRR0H = 0;
					UBRR0L = 9;	
					break;
				case 20000000L:
					UCSR0A = 0;
					UBRR0H = 0;
					UBRR0L = 10;	
					break;
			}
			break;
		case 38400L:
			switch(f_cpu){
				case 8000000L:
					UCSR0A = 0;
					UBRR0H = 0;
					UBRR0L = 12;	
					break;
			}
			break;
	}
	// enable RS232 RX and TX, RX interrupt
	UCSR0B = _BV(RXEN0)|_BV(TXEN0)|_BV(RXCIE0);
	// set 8N1 frame format
	UCSR0C = _BV(UCSZ01)|_BV(UCSZ00);
  }

SIGNAL(USART_RX_vect){
	// receive a complete message then call the app
	if(!RS232_msg_started){
		// ignore everything  but our start code
		if(UDR0 == MSG_ESC){
			*msg_buff = MSG_ESC;
			RS232_msg_started = true;
			RS232_buffer_pos = 1;
		}
	}else{
		// got the start code, get the rest of the message
		if(RS232_buffer_pos == 1){
			RS232_msg_len = UDR0;
			msg_buff[RS232_buffer_pos++] = RS232_msg_len;
		} else {
			msg_buff[RS232_buffer_pos++] = UDR0;
			if(RS232_buffer_pos == RS232_msg_len){
				RS232_msg_started = false;
				RS232_msg_crc = p_msg_wrap->msg_crc;
				p_msg_wrap->msg_crc = 0;
				if(make_crc(msg_buff, RS232_msg_len) == RS232_msg_crc){
					// call app to process the message
					if((*RS232_process_msg)()){
						// send an ack
						p_msg_wrap->msg_esc = MSG_ESC;
						p_msg_wrap->msg_len = sizeof(MSG_WRAP);
						p_msg_wrap->msg_cmd_data[0] = ACK_CMD;
						p_msg_wrap->msg_crc = 0;
						p_msg_wrap->msg_crc = make_crc(msg_buff, p_msg_wrap->msg_len);
						send_msg(msg_buff, p_msg_wrap->msg_len);
					}
				}
			}
		}
	}
}

void RS232_write(char x) {
  // wait for empty receive buffer
  while ((UCSR0A & _BV(UDRE0))==0);
  // send
  UDR0 = x;
}

uint8_t RS232_char_is_waiting() {
  // returns 1 if a character is waiting
  // returns 0 if not
  return (UCSR0A & _BV(RXC0));
}

char RS232_read() {
  // wait
  while(!RS232_char_is_waiting());
  char x = UDR0;
  return x;
}

int RS232_putchar(char c, FILE *stream) {
  RS232_write(c);
  return 0;
}
    
int RS232_getchar(FILE *stream) {
  int x = RS232_read();
  return x;
}

int PutCommChar(unsigned char chrOut){
  RS232_write(chrOut);
  return 0;
}

int GetCommChar(unsigned char *chrIn){
  unsigned char x = RS232_read();
  *chrIn = x;
  return 0;
}

