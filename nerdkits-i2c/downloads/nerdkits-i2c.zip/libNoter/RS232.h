#ifndef __RS232_H
#define __RS232_H

#include <inttypes.h>
#include <stdio.h>

void init_RS232(uint32_t f_cpu, uint32_t baud_rate, int (*call_back)());
void RS232_write(char x);
uint8_t RS232_char_is_waiting();
char RS232_read();

int RS232_putchar(char x, FILE *stream);
int RS232_getchar(FILE *stream);
int PutCommChar(unsigned char chrOut);
int GetCommChar(unsigned char *chrIn);
#endif
