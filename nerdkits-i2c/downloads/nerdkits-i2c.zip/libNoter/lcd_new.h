// lcd_new.h - Noter's mod to Nerdkits lcd.c, lcd.h
//
// usage -
//
//	FILE lcd_stream;
//
//	lcd_init();
//	fdev_setup_stream(&lcd_stream, lcd_putchar, 0, _FDEV_SETUP_WRITE); 
//	lcd_clear_and_home();
//	fprintf_P(&lcd_stream, PSTR("Alive on ATmega32U4")); 


#include <avr/io.h>
#include <avr/pgmspace.h>
#include <inttypes.h>
#include <stdio.h>
#include <util/delay.h>
#include <stdio.h>

#ifndef __LCD_NEW_H
#define __LCD_NEW_H

// pin I/O macros
//
#define LCD_INPUT2(port,pin) DDR ## port &= ~_BV(pin) 
#define LCD_OUTPUT2(port,pin) DDR ## port |= _BV(pin) 
#define LCD_CLEAR2(port,pin) PORT ## port &= ~_BV(pin) 
#define LCD_SET2(port,pin) PORT ## port |= _BV(pin) 
#define LCD_TOGGLE2(port,pin) PORT ## port ^= _BV(pin) 
#define LCD_READ2(port,pin) ((PIN ## port & _BV(pin))?1:0)
#define LCD_STATE2(port,pin) ((DDR ## port & _BV(pin))?1:0)
//
#define LCD_INPUT(x) LCD_INPUT2(x) 
#define LCD_OUTPUT(x) LCD_OUTPUT2(x)
#define LCD_CLEAR(x) LCD_CLEAR2(x)
#define LCD_SET(x) LCD_SET2(x)
#define LCD_TOGGLE(x) LCD_TOGGLE2(x)
#define LCD_READ(x) LCD_READ2(x)
#define LCD_STATE(x) LCD_STATE2(x)
#define LCD_PULLUP_ON(x) LCD_INPUT2(x); LCD_SET2(x)
#define LCD_PULLUP_OFF(x) LCD_INPUT2(x); LCD_CLEAR2(x)

// PIN DEFINITIONS:
#if defined(__AVR_ATmega168__) || defined(__AVR_ATmega328P__)

	#define LCD_DB4		D,2
	#define LCD_DB5		D,3
	#define LCD_DB6		D,4
	#define LCD_DB7		D,5
	#define LCD_E			D,6
	#define LCD_RS			D,7

#elif defined(__AVR_ATmega32U4__)

	#define LCD_RS			D,4
	#define LCD_E			D,6
	#define LCD_DB4		D,7
	#define LCD_DB5		B,4
	#define LCD_DB6		B,5
	#define LCD_DB7		B,6

#else
	#error !cpu not supported by lcd_new.h
#endif

static inline void lcd_set_type_data() {
	LCD_SET(LCD_RS);
}

static inline void lcd_set_type_command() {
	LCD_CLEAR(LCD_RS);
}

void lcd_write_nibble(char c) {
  // set data
//  PORTD &= ~(0x0f << 2);
//  PORTD |= (c&0x0f) << 2;
	if(c&0x01) LCD_SET(LCD_DB4); else LCD_CLEAR(LCD_DB4);
	if(c&0x02) LCD_SET(LCD_DB5); else LCD_CLEAR(LCD_DB5);
	if(c&0x04) LCD_SET(LCD_DB6); else LCD_CLEAR(LCD_DB6);
	if(c&0x08) LCD_SET(LCD_DB7); else LCD_CLEAR(LCD_DB7);

  // E high
//  PORTD |= (1<<PD6);
	LCD_SET(LCD_E);
  _delay_us(1);
  // E low
//  PORTD &= ~(1<<PD6);
	LCD_CLEAR(LCD_E);
  _delay_us(1);
}

void lcd_write_byte(char c) {
  lcd_write_nibble( (c >> 4) & 0x0f );
  lcd_write_nibble( c & 0x0f );
  _delay_us(80);
}

void lcd_clear_and_home() {
  lcd_set_type_command();
  lcd_write_byte(0x01);
  _delay_ms(50);
  lcd_write_byte(0x02);
  _delay_ms(50);
}

void lcd_home() {
  lcd_set_type_command();
  lcd_write_byte(0x02);
  _delay_ms(50);
}

static inline void lcd_write_data(char c) {
  lcd_set_type_data();
  lcd_write_byte(c);
}

void lcd_write_string(const char *x) {
  // assumes x is in program memory
  while(pgm_read_byte(x) != 0x00)
    lcd_write_data(pgm_read_byte(x++));
}

void lcd_goto_position(uint8_t row, uint8_t col) {
  lcd_set_type_command();
  // 20x4 LCD: offsets 0, 0x40, 20, 0x40+20
  uint8_t row_offset = 0;
  switch(row) {
    case 0: row_offset = 0; break;
    case 1: row_offset = 0x40; break;
    case 2: row_offset = 20; break;
    case 3: row_offset = 0x40+20; break;
  }
  lcd_write_byte(0x80 | (row_offset + col));
}

void lcd_line_one()   { lcd_goto_position(0, 0); }
void lcd_line_two()   { lcd_goto_position(1, 0); }
void lcd_line_three() { lcd_goto_position(2, 0); }
void lcd_line_four()  { lcd_goto_position(3, 0); }

// PD2-5 -- LCD DB4-7 (pins 11-14) (was PB3-6)
// PD6 -- LCD E (pin 6) (was PA5)
// PD7 -- LCD RS (pin 4) (was PA4)

void lcd_init() {
  // set pin driver directions
	LCD_OUTPUT(LCD_DB4);
	LCD_OUTPUT(LCD_DB5);
	LCD_OUTPUT(LCD_DB6);
	LCD_OUTPUT(LCD_DB7);
	LCD_OUTPUT(LCD_E);
	LCD_OUTPUT(LCD_RS);

  // wait 100msec
  _delay_ms(100);
  lcd_set_type_command();
  
  // do reset
  lcd_write_nibble(0x03);
  _delay_ms(6);
  lcd_write_nibble(0x03);
  _delay_us(250);
  lcd_write_nibble(0x03);
  _delay_us(250);
  
  // write 0010 (data length 4 bits)
  lcd_write_nibble(0x02);
  // set to 2 lines, font 5x8
  lcd_write_byte(0x28);
  // disable LCD
  //lcd_write_byte(0x08);
  // enable LCD
  lcd_write_byte(0x0c);
  // clear display
  lcd_write_byte(0x01);
  _delay_ms(5);
  // enable LCD
  lcd_write_byte(0x0c);
  // set entry mode
  lcd_write_byte(0x06);

  // set cursor/display shift
  lcd_write_byte(0x14);

  // clear and home
  lcd_clear_and_home();
}

int lcd_putchar(char c, FILE *stream) {
  lcd_write_data(c);
  return 0;
}

int lcd_scroller(char chr, FILE *stream) {
	static char lcd_char[4][20];
	static uint8_t lcd_line;
	static uint8_t lcd_col;

	if(lcd_col==20){
		lcd_col = 0;
		lcd_line++;
	}

	if(lcd_line==4){
		for(uint8_t l=0;l<3;l++){
			lcd_goto_position(l, 0);
			for(uint8_t c=0;c<20;c++){
				lcd_char[l][c] = lcd_char[l+1][c];
				lcd_write_data(lcd_char[l][c]);
			}
		}
		lcd_line=3;
		lcd_col=0;
		lcd_goto_position(lcd_line, 0);
	}

  lcd_write_data(chr);
	lcd_char[lcd_line][lcd_col++] = chr;
  return 0;
}

#endif

