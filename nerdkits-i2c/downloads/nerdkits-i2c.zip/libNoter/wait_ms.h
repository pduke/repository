// wait_ms.c
// 
// Define countdown variable and functions
//
volatile uint16_t wait_count;
void (*wait_callback)();
void wait_ms_init(uint32_t f_cpu);
void wait_ms_init_callback(uint32_t f_cpu, void (*callback)());
void wait_ms(uint16_t ms);
