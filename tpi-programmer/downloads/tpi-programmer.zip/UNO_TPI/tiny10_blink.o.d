tiny10_blink.o: tiny10_blink.c
