tiny10_toggle.o: tiny10_toggle.c
