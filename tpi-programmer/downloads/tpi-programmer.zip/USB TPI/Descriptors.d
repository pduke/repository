Descriptors.o: Descriptors.c Descriptors.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/USB.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/../../Common/Common.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/../../Common/Architectures.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/../../Common/BoardTypes.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/../../Common/ArchitectureSpecific.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/../../Common/CompilerSpecific.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/../../Common/Attributes.h \
 Config/LUFAConfig.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/../../Common/Endianness.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/USBMode.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/USBTask.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/../../../Common/Common.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/USBMode.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/USBController.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/AVR8/USBController_AVR8.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/AVR8/../../../../Common/Common.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/AVR8/../USBMode.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/AVR8/../Events.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/AVR8/../../../../Common/Common.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/AVR8/../USBMode.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/AVR8/../USBTask.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/AVR8/../USBInterrupt.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/AVR8/../AVR8/USBInterrupt_AVR8.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/AVR8/../AVR8/../../../../Common/Common.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/AVR8/../AVR8/../USBMode.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/AVR8/../AVR8/../Events.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/AVR8/../AVR8/../USBController.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/AVR8/../Device.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/AVR8/../StdDescriptors.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/AVR8/../Events.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/AVR8/../USBInterrupt.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/AVR8/../Endpoint.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/AVR8/../AVR8/Endpoint_AVR8.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/AVR8/../AVR8/../USBTask.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/AVR8/../AVR8/../USBInterrupt.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/AVR8/../AVR8/Device_AVR8.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/AVR8/../AVR8/../StdDescriptors.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/AVR8/../AVR8/../Endpoint.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/AVR8/../Endpoint.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/AVR8/../DeviceStandardReq.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/AVR8/../StdRequestType.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/AVR8/../USBTask.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/AVR8/../USBController.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/AVR8/../EndpointStream.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/AVR8/../AVR8/EndpointStream_AVR8.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/Events.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/StdRequestType.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/StdDescriptors.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/DeviceStandardReq.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/Events.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/StdDescriptors.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/ConfigDescriptors.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/HostStandardReq.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/USBController.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/USBInterrupt.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/Device.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/Endpoint.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/DeviceStandardReq.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/EndpointStream.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Class/AndroidAccessoryClass.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Class/../Core/USBMode.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Class/AudioClass.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Class/Device/AudioClassDevice.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Class/Device/../../USB.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Class/Device/../Common/AudioClassCommon.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Class/Device/../Common/../../Core/StdDescriptors.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Class/CDCClass.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Class/Device/CDCClassDevice.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Class/Device/../Common/CDCClassCommon.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Class/HIDClass.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Class/Device/HIDClassDevice.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Class/Device/../Common/HIDClassCommon.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Class/Device/../Common/HIDParser.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Class/Device/../Common/../../../../Common/Common.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Class/Device/../Common/HIDReportData.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Class/Device/../Common/HIDClassCommon.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Class/MassStorageClass.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Class/Device/MassStorageClassDevice.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Class/Device/../Common/MassStorageClassCommon.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Class/MIDIClass.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Class/Device/MIDIClassDevice.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Class/Device/../Common/MIDIClassCommon.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Class/Device/../Common/AudioClassCommon.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Class/PrinterClass.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Class/RNDISClass.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Class/Device/RNDISClassDevice.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Class/Device/../Common/RNDISClassCommon.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Class/Device/../Common/CDCClassCommon.h \
 /home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Class/StillImageClass.h

Descriptors.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/USB.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/../../Common/Common.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/../../Common/Architectures.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/../../Common/BoardTypes.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/../../Common/ArchitectureSpecific.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/../../Common/CompilerSpecific.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/../../Common/Attributes.h:

Config/LUFAConfig.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/../../Common/Endianness.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/USBMode.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/USBTask.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/../../../Common/Common.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/USBMode.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/USBController.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/AVR8/USBController_AVR8.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/AVR8/../../../../Common/Common.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/AVR8/../USBMode.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/AVR8/../Events.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/AVR8/../../../../Common/Common.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/AVR8/../USBMode.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/AVR8/../USBTask.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/AVR8/../USBInterrupt.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/AVR8/../AVR8/USBInterrupt_AVR8.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/AVR8/../AVR8/../../../../Common/Common.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/AVR8/../AVR8/../USBMode.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/AVR8/../AVR8/../Events.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/AVR8/../AVR8/../USBController.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/AVR8/../Device.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/AVR8/../StdDescriptors.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/AVR8/../Events.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/AVR8/../USBInterrupt.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/AVR8/../Endpoint.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/AVR8/../AVR8/Endpoint_AVR8.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/AVR8/../AVR8/../USBTask.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/AVR8/../AVR8/../USBInterrupt.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/AVR8/../AVR8/Device_AVR8.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/AVR8/../AVR8/../StdDescriptors.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/AVR8/../AVR8/../Endpoint.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/AVR8/../Endpoint.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/AVR8/../DeviceStandardReq.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/AVR8/../StdRequestType.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/AVR8/../USBTask.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/AVR8/../USBController.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/AVR8/../EndpointStream.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/AVR8/../AVR8/EndpointStream_AVR8.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/Events.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/StdRequestType.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/StdDescriptors.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/DeviceStandardReq.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/Events.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/StdDescriptors.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/ConfigDescriptors.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/HostStandardReq.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/USBController.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/USBInterrupt.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/Device.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/Endpoint.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/DeviceStandardReq.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Core/EndpointStream.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Class/AndroidAccessoryClass.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Class/../Core/USBMode.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Class/AudioClass.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Class/Device/AudioClassDevice.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Class/Device/../../USB.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Class/Device/../Common/AudioClassCommon.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Class/Device/../Common/../../Core/StdDescriptors.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Class/CDCClass.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Class/Device/CDCClassDevice.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Class/Device/../Common/CDCClassCommon.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Class/HIDClass.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Class/Device/HIDClassDevice.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Class/Device/../Common/HIDClassCommon.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Class/Device/../Common/HIDParser.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Class/Device/../Common/../../../../Common/Common.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Class/Device/../Common/HIDReportData.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Class/Device/../Common/HIDClassCommon.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Class/MassStorageClass.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Class/Device/MassStorageClassDevice.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Class/Device/../Common/MassStorageClassCommon.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Class/MIDIClass.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Class/Device/MIDIClassDevice.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Class/Device/../Common/MIDIClassCommon.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Class/Device/../Common/AudioClassCommon.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Class/PrinterClass.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Class/RNDISClass.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Class/Device/RNDISClassDevice.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Class/Device/../Common/RNDISClassCommon.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Class/Device/../Common/CDCClassCommon.h:

/home/paul/AVR/LUFA-120730/LUFA/../LUFA/Drivers/USB/Class/StillImageClass.h:
