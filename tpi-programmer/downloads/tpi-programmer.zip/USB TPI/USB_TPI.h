//
// AVR_TPI.c - Noter's TPI (Tiny Programming Interface) programmer for the NerdKit
// - Turn the NerdKit into an AVR910 (AVR TPI) TPI programmer
// - High Voltage (+12v) programming for ATtiny4/5/9/10
//
// v1.0 - Based on AVR_ISP.c
//

#ifndef _USB_TPI_H_
#define _USB_TPI_H_

    /* Includes: */
			#include <avr/io.h>
			#include <avr/wdt.h>
			#include <avr/interrupt.h>
			#include <avr/power.h>
			#include <avr/pgmspace.h>
			#include <util/delay.h>
			#include <stdbool.h>
			#include <avr/eeprom.h>
			#include <libNoter/lcd_Noter_4_bit.h>
			#include <libNoter/pin_io_macros.h>

			#include "Descriptors.h"

			#include <LUFA/Version.h>
			#include <LUFA/Drivers/Misc/RingBuffer.h>
			#include <LUFA/Drivers/USB/USB.h>
		
		// use/connect reset or 12v but not both
		#define USE_12v true

		// define ports, pins
		//
		#if defined(__AVR_ATmega32U4__)

			#define __RESET			F,0
			#define TPI_CLK			F,4
			#define TPI_DATA		F,1

		#elif defined(__AVR_AT90USB162__)

			#define __RESET			B,5
			#define __12v				B,5
			#define TPI_CLK			D,7
			#define TPI_DATA		B,0

		#else
			#error !mpu not supported by AVR_TPI.c
		#endif

		// TPI KEY 
		#define NVM_PROGRAM_ENABLE 0x1289AB45CDD888FF
		bool in_programming_mode = false;

		// TPI Instruction Set
		#define SLD						0b00100000
		#define SLD_POSTINC		0b00100100
		#define SST						0b01100000
		#define SST_POSTINC		0b01100100
		#define SSTPR					0b01101000
		#define SIN						0b00010000
		#define SOUT						0b10010000
		#define SLDCS					0b10000000
		#define SSTCS					0b11000000
		#define SKEY						0b11100000

		// TPI Control and Status Registers
		#define TPISR					0b00000000
		#define TPIPCR					0b00000010
		#define TPIIR					0b00001111

		// TIPSR bits
		#define NVMEM					0b00000010

		// NVM Commands
		#define NVMCMD_NO_OPERATION		0x00
		#define NVMCMD_CHIP_ERASE			0x10
		#define NVMCMD_SECTION_ERASE		0x14
		#define NVMCMD_MEMORY_WRITE		0x1D

		#define words_to_write 	1

		// register addresss
		#define NVMCSR 0X32
		#define NVMCMD 0X33

		// Memory space definitions
		#define IO_SPACE_START						0x0000
		#define IO_SPACE_END							0x003F	
		#define SRAM_DATA_MEMORY_START	0x0040 
		#define SRAM_DATA_MEMORY_END			0x005F	
		#define NVM_LOCK_BITS_START			0x3F00
		#define NVM_LOCK_BITS_SIZE				2
		#define CONF_BITS_START						0x3F40
		#define CONF_BITS_SIZE						2
		#define CALIB_BITS_START					0x3F80 
		#define CALIB_BITS_SIZE					2
		#define DEV_ID_START							0x3FC0
		#define DEV_ID_SIZE								3 
		#define NVM_PROG_MEM_START				0x4000
		#define NVM_PROG_MEM_END					0x43FF

		#define GUARD_TIME_128			0
		#define GUARD_TIME_64				1
		#define GUARD_TIME_32				2
		#define GUARD_TIME_16				3
		#define GUARD_TIME_8				4
		#define GUARD_TIME_4				5
		#define GUARD_TIME_2				6
		#define GUARD_TIME_0				7

		// tpi variables/values/macros
		#define TPI_OK					0
		#define TPI_TIMEOUT		1
		#define TPI_ERROR			2
		#define MEMORY_TYPE_FLASH 'F'
		#define MEMORY_TYPE_EEPROM 'E'
		#define SIG_LEN 3


		/* Function Prototypes: */
		void EVENT_USB_Device_ConfigurationChanged(void);
		void EVENT_USB_Device_ControlRequest(void);

		uint8_t uart_read_q(void);
		ISR(USART_RX_vect, ISR_BLOCK);
		void uart_writeX(char x);
		ISR(USART1_RX_vect, ISR_BLOCK);
		void uart_writeX(char x);
		void uart_write_PSTR(const char *data);
		ISR(TIMER0_COMPA_vect, ISR_BLOCK);
		ISR(TIMER0_OVF_vect, ISR_BLOCK);
		uint8_t read_tpi_q(void);
		void write_tpi_q(uint8_t data);
		void write_nvm_command(uint8_t nvm_command);
		void write_nvm_address(volatile uint16_t nvm_address);
		uint8_t read_nvm_byte(void);
		void write_nvm_word(volatile uint16_t data);
		bool nvm_busy(void);
		uint8_t get_signature(void);
		void tpi_leave_programming_mode(void);
		uint8_t tpi_enter_programming_mode(void);
		void show_device_name(void);
		void universal_read_fuse(uint16_t address);
		void universal_write_fuse(uint16_t address);

#endif
