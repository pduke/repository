#include "USB_TPI.h"

// use reset or HV, one or the other but not both
#define RESET_TO_GND 		CLEAR(__RESET)
#define RESET_TO_5v 		SET(__RESET)
#define HV_TO_5v				SET(__12v)
#define HV_TO_12v				CLEAR(__12v)
 
// TPI ring buffers
//
#define TPI_Q_SIZE 16
volatile uint8_t tpi_input_buff[TPI_Q_SIZE];
volatile uint8_t tpi_input_qin=0;
volatile uint8_t tpi_input_qout=0;
volatile uint8_t tpi_input_bit=12;

volatile uint8_t tpi_output_buff[TPI_Q_SIZE];
volatile uint8_t tpi_output_qin=0;
volatile uint8_t tpi_output_qout=0;
volatile uint8_t tpi_output_bit=0;

// USB specific - ring buffer
//
#define Q_SIZE 128
volatile uint8_t q_buff[Q_SIZE];
volatile uint8_t qin;
volatile uint8_t qout;

USB_ClassInfo_CDC_Device_t VirtualSerial_CDC_Interface =
	{
		.Config =
			{
				.ControlInterfaceNumber   = 0,
				.DataINEndpoint           =
					{
						.Address          = CDC_TX_EPADDR,
						.Size             = CDC_TXRX_EPSIZE,
						.Banks            = 1,
					},
				.DataOUTEndpoint =
					{
						.Address          = CDC_RX_EPADDR,
						.Size             = CDC_TXRX_EPSIZE,
						.Banks            = 1,
					},
				.NotificationEndpoint =
					{
						.Address          = CDC_NOTIFICATION_EPADDR,
						.Size             = CDC_NOTIFICATION_EPSIZE,
						.Banks            = 1,
					},
			},
	};

FILE lcd_stream;

// programmer info
//
#define PROGRAMMER_ID		"USB TPI"
#define HARDWARE_VERSION 	"10"
#define SOFTWARE_VERSION	"10"

/* Supported Devices 
* +-------+----------+------+-------+------+------+------+-------+
* |Device |Signature | Code | Flash |EEProm| Lock | Fuse | PMode |
* +-------+----------+------+-------+------+------+------+-------+
* |tiny85 | 1E 93 0B | 0x01 |  R/W  | R/W  | R/W  | R/W  | Page  |
* |mega168| 1E 94 06 | 0x02 |  R/W  | R/W  | R/W  | R/W  | Page  |
* |mega328| 1E 95 0F | 0x03 |  R/W  | R/W  | R/W  | R/W  | Page  |
* +-------+----------+------+-------+------+------+------+-------+
*/
typedef struct {
	char			name[10];
	uint8_t		signature[SIG_LEN];
	uint8_t		device_code;
	uint16_t	flash_offset;	
	uint16_t	page_size;
	uint16_t	page_count;
}	AVR_DEVICE;
AVR_DEVICE target_avr;
#define DEVICE_COUNT sizeof(avr_info)/sizeof(AVR_DEVICE)
const AVR_DEVICE	avr_info[] PROGMEM =	{
													{	"ATtiny4",
														"\x1E\x8F\x0A",
														0x14,
														0x4000,
														8,
														32
													},
													{	"ATtiny5",
														"\x1E\x8F\x09",
														0x15,
														0x4000,
														8,
														32
													},
													{	"ATtiny9",
														"\x1E\x90\x08",
														0x19,
														0x4000,
														8,
														64
													},
													{	"ATtiny10",
														"\x1E\x90\x03",
														0x10,
														0x4000,
														8,
														64
													}
												};

uint8_t AVR_Signature[SIG_LEN];
bool in_programming_mode;
uint16_t address;
uint16_t flash_byte_count;

// --------------------------------------------------------------------------------------
// get data from avrdude
uint8_t uart_read_q(void){
	uint8_t data;
	while(qout==qin){
		while(CDC_Device_BytesReceived(&VirtualSerial_CDC_Interface)>0){
			data = CDC_Device_ReceiveByte(&VirtualSerial_CDC_Interface);
			q_buff[qin++]=data;
			if(qin==Q_SIZE) qin=0;
		}
	}
	data=q_buff[qout++];
	if(qout==Q_SIZE) qout=0;
	return(data);
}

// send data to avrdude
#if defined(__AVR_ATmega32U4__) || defined(__AVR_AT90USB162__)
	void uart_writeX(char x) {
		CDC_Device_SendByte(&VirtualSerial_CDC_Interface, x);
		}
#else
	#error !cpu not supported by USB_TPI.c
#endif

	// simply send a flash const string to avrdude
void uart_write_PSTR(const char *data){
	int i;
	for(i=0;pgm_read_byte_near((char*)&data[i]);i++)
		uart_writeX(pgm_read_byte_near((char*)&data[i]));
}

// trailing edge of TPI clock pulse
// setup data
uint8_t xmit_byte=0;
uint8_t parity=0;
ISR(TIMER0_COMPA_vect, ISR_BLOCK) {
	CLEAR(TPI_CLK); // falling edge of clock pulse
	// set up if data to transmit
	if(tpi_output_bit != 0){
		if(tpi_output_bit ==1 ){
			tpi_output_bit++; // start_bit
			OUTPUT(TPI_DATA);
			CLEAR(TPI_DATA);
		} else {
			if(tpi_output_bit <10 ){
				if(xmit_byte & _BV((tpi_output_bit)-2)){
					SET(TPI_DATA); // 1
					parity ^= 1;
				} else {
					CLEAR(TPI_DATA); // 0
				}
				tpi_output_bit++;
			} else {
				if(tpi_output_bit == 10){
					if(parity){
						SET(TPI_DATA);
					} else {
						CLEAR(TPI_DATA);
					}
					tpi_output_bit++;
				} else {
					if(tpi_output_bit <13 ){
						SET(TPI_DATA); // stop bit
						tpi_output_bit++;
					} else {
						PULLUP_ON(TPI_DATA); // idle
						tpi_output_bit = 0; // done
					}
				}
			}
		}
	} else {
		if(tpi_output_qin != tpi_output_qout){
			xmit_byte = tpi_output_buff[tpi_output_qout++]; // get byte from que
			tpi_output_qout &= (TPI_Q_SIZE - 1); // wrap que pointer if necessary
			tpi_output_bit=1; // set bit pointer
			parity = 0;
		}
	}
}

// leading edge of TPI clock pulse
// read data 
uint8_t recv_byte = 0;
volatile uint8_t leading_edge_count;
//volatile uint8_t tpi_read_count;
ISR(TIMER0_OVF_vect, ISR_BLOCK) {
	SET(TPI_CLK); // leading edge of clock pulse
	if(tpi_output_bit == 0){ // not transmitting
		if(tpi_input_bit != 0){
			if(tpi_input_bit<9){ // data bits
				tpi_input_bit++;
				recv_byte = ((recv_byte >> 1) | (READ(TPI_DATA)<<7));
				parity ^= READ(TPI_DATA);
			} else {
				if(tpi_input_bit==9){ // parity bit
					tpi_input_bit++;
					if(READ(TPI_DATA) != parity){
						tpi_input_bit = 0; // ignore byte if bad parity
					}
				} else {
					if(tpi_input_bit<12){ // stop bits
						tpi_input_bit++;
						if(READ(TPI_DATA)==0){
							tpi_input_bit = 0; // ignore byte if missing stop bit
						}
					} else {
						tpi_input_buff[tpi_input_qin++] = recv_byte; // store byte in que
						tpi_input_qin &= (TPI_Q_SIZE - 1); // wrap que pointer if necessary
						tpi_input_bit = 0; // done
					}
				}
			}
		} else {
				if ((tpi_output_qin==tpi_output_qout) // skip if xmit active
				&& (tpi_output_bit==0)){ // skip if xmit active
				if(READ(TPI_DATA)==0){ // look for start bit
					recv_byte = 0x00; // clear for shifting
					tpi_input_bit=1; // set bit flag for 1st data bit
					parity = 0;	// clear for calc
				} else {
					leading_edge_count++;
				}
			}
		}
	}
}

uint8_t read_tpi_q(void){
	uint8_t tpi_char;
	leading_edge_count = 0;
	while(tpi_input_qin==tpi_input_qout && leading_edge_count<222); // wait for char
	if(leading_edge_count>221){ // timeout waiting for start bit
		return(0x00); // have to give something - null will cause error early on
	} else {
		tpi_char = tpi_input_buff[tpi_input_qout++]; // get char
		tpi_input_qout &= (TPI_Q_SIZE - 1); // wrap que pointer if necessary
		return(tpi_char);
	}
}

void write_tpi_q(uint8_t data){
//	OUTPUT(TPI_DATA); // force idle state
//	SET(TPI_DATA);
	uint8_t qin = tpi_output_qin+1;
	qin &= (TPI_Q_SIZE - 1);
	while(qin == tpi_output_qout); // wait for chars to xmit
	tpi_output_buff[tpi_output_qin++]=data; // put byte in que
	tpi_output_qin &= (TPI_Q_SIZE - 1); // wrap que pointer if necessary
}

// Send NVM Command to be exectued via TPI
void write_nvm_command(uint8_t nvm_command){
	write_tpi_q(SOUT | ((NVMCMD & 0XF0)<<1) | (NVMCMD & 0X0F));
	write_tpi_q(nvm_command);
}

// Send address of the NVM location to be accessed via TPI
void write_nvm_address(volatile uint16_t nvm_address){
	write_tpi_q(SSTPR);//Address Low Byte
	write_tpi_q(((uint8_t)nvm_address & 0x00FF));
	write_tpi_q(SSTPR | 0X01);//Address High Byte
	write_tpi_q((uint8_t)(nvm_address >>8));
}

// Read one byte from NVM via TPI
uint8_t read_nvm_byte(void){
	write_tpi_q(SLD_POSTINC);
	return read_tpi_q();
}

// Write whole word to NVM  via TPI
void write_nvm_word(volatile uint16_t data){
	write_tpi_q(SST_POSTINC);
	write_tpi_q(data & 0X00FF); // low byte
	write_tpi_q(SST_POSTINC);
	write_tpi_q(data >> 8); // high byte
}

// Check if NVM is busy by reading NVMCSR
bool nvm_busy(void){
	write_tpi_q(SIN |((NVMCSR & 0XF0)<<1) | (NVMCSR & 0X0F));
	if(read_tpi_q() == 0x80) return true;
	return false;
}

// get the signature from the target device and load related info for the target.
// signature is 3 bytes read 1 at a time. The use to lookup dev info in table.	
uint8_t get_signature(void){
		write_nvm_command(NVMCMD_MEMORY_WRITE);
		write_nvm_address(DEV_ID_START);
		for(uint8_t i=0; i<SIG_LEN; i++){
			AVR_Signature[i] = read_nvm_byte();
		}
		for(uint8_t i=0;i<DEVICE_COUNT;i++){
			if(!memcmp_P(AVR_Signature,avr_info[i].signature,SIG_LEN)){
				for(uint8_t j=0;j<sizeof(AVR_DEVICE);j++)
					((char*)&target_avr)[j] = pgm_read_byte_near(&((char*)&avr_info[i])[j]);
				return(TPI_OK);
			}
		}
//	}
	return(TPI_ERROR);
}

// Power off the target mcu
void tpi_leave_programming_mode(void){
	if(in_programming_mode){
		// clear NVMEM
		write_tpi_q(SSTCS | NVMEM);
		write_tpi_q(~NVMEM);
	}
	// stop the serial clock
	TCCR0B = 0;
	// set direction input with pullup disabled
	PULLUP_OFF(TPI_DATA);
	PULLUP_OFF(TPI_CLK);
	// reset target mcu
	if(USE_12v){
		HV_TO_5v;
		_delay_ms(10);
		HV_TO_12v;
		_delay_ms(10);
		HV_TO_5v;
	} else {
		RESET_TO_5v;
		_delay_ms(10);
		RESET_TO_GND;
		_delay_ms(10);
		RESET_TO_5v;
	}
	in_programming_mode = false;
}

// enter programming mode and set guard time
// get signature and show on lcd
uint8_t tpi_enter_programming_mode(void){
	if(!in_programming_mode){
		// setup shift registers
		tpi_output_bit=12;
		tpi_input_bit=0;

		// empty que's
		tpi_output_qin = 0;
		tpi_output_qout = 0;
		tpi_input_qin = 0;
		tpi_input_qout = 0;

		// set clock high
		OUTPUT(TPI_CLK);
		SET(TPI_CLK);

		// set pullup on data
		PULLUP_ON(TPI_DATA);

		// this puts the chip in programming mode
		// either pull down reset or enable the 12v supply
		// reset is connected via n-type mosfet so it is inverted.
		if(USE_12v){
			HV_TO_12v;
		} else {
			RESET_TO_GND;
		}
		_delay_ms(10); // give time for rise

		// start the serial clock
		TCCR0B = _BV(CS00);
		_delay_ms(2); // wait for at least 16 clock cycles

		// enable programming with key value
		uint64_t key = NVM_PROGRAM_ENABLE;
		write_tpi_q(SKEY);
		for(int8_t i=0;i<8;i++){
			write_tpi_q(key & 0xFF);
			key >>= 8;
		}

		// wait for NVMEM to be set in TPISR
		uint8_t enabled = 0;
		uint8_t tries = 10;
		while(enabled==0 && tries-- > 0){
			write_tpi_q(SLDCS | TPISR);
		 	enabled = read_tpi_q() & NVMEM;
		}
		if(enabled == 0) return(TPI_ERROR);

		// set guard time
		write_tpi_q(SSTCS | TPIPCR);
		write_tpi_q(GUARD_TIME_2);

		in_programming_mode = true;

		if(get_signature()!=TPI_OK){
			tpi_leave_programming_mode();
			memcmp_P(target_avr.name,PSTR("error"),6);
		}
	}

	return(TPI_OK);
}

// show what is connected on the LCD
void show_device_name(void){
	fprintf_P(&lcd_stream, PSTR("[%s]"),target_avr.name); 
}

// routines to process universal commands from avrdude
void universal_read_fuse(uint16_t address){
	uart_read_q();
	uart_read_q();
	write_nvm_address(address);
	uart_writeX(read_nvm_byte());
	uart_writeX('\r');
}

void universal_write_fuse(uint16_t address){
	uart_read_q();
	uint8_t value = uart_read_q();
	fprintf_P(&lcd_stream, PSTR("%02X"),value);
	// erase first
	write_nvm_command((uint8_t)NVMCMD_SECTION_ERASE);
	write_nvm_address(address);
	write_nvm_word(0xFFFF);
	while(nvm_busy());
	// then write new value
	write_nvm_command(NVMCMD_MEMORY_WRITE);
	write_nvm_address(address);
	write_nvm_word(0xFF00 | value);
	while(nvm_busy());
	uart_writeX(0x00);
	uart_writeX('\r');
}

// --------------------------------------------------------------------------------------------------------
int main(void)
{
	// Initialize LCD and identify
	lcd_init();
	lcd_cursor_blink(true);
	fdev_setup_stream(&lcd_stream, lcd_putchar, 0, _FDEV_SETUP_WRITE); 
	lcd_clear_and_home();
	fprintf_P(&lcd_stream, PSTR("USB_TPI "));

	enum PATTERNS {
		pat_0,
		pat_1,
		pat_2,
		pat_3,
		pat_4,
		pat_5,
		pat_6,
		pat_7
	};

	lcd_set_pattern(pat_0,	0b00100,
													0b00100,
													0b11111,
													0b00100,
													0b00100,
													0b11111,
													0b00100,
													0b00100);

	fprintf_P(&lcd_stream, PSTR("%c"),pat_0);

	// SetUp the timer for the TPI clock
	TIMSK0 |= _BV(OCIE0A) | _BV(TOV0);
	OCR0A = 128;

	// Disable watchdog if enabled by bootloader/fuses
	MCUSR &= ~(1 << WDRF);
	wdt_disable();

	// Disable clock division
	clock_prescale_set(clock_div_1);

	// USB Hardware Initialization
	USB_Init();

	// enable interrupts
	sei();

	// set non-programming state
	// connect either reset or 12v but not both !
	if(USE_12v){
		HV_TO_5v;
		OUTPUT(__12v);
	} else {
		RESET_TO_5v;
		OUTPUT(__RESET);
	}

	tpi_leave_programming_mode();

	// process commands from host
	uint8_t save_byte=0;
	uint8_t command;
	uint16_t u_cmd;
	uint8_t u_offset;
	uint16_t byte_count=0;
	uint8_t mem_type;
	while(true){
										//  Commands                           	| Host writes | Host reads |      |
										//  --------                           	+-----+-------+------+-----+      |
										//                                     	| ID  | data  | data |     | Note |
		command=uart_read_q();
		if(command=='P'){
			lcd_clear_and_home();
			fprintf_P(&lcd_stream, PSTR("USB_TPI "));
		}
		fprintf_P(&lcd_stream, PSTR(">%c"),command);
		switch(command){
			case 'P':			// | Enter programming mode            	| 'P' |       |      | 13d |   1  |
				if(tpi_enter_programming_mode()==TPI_OK)
					uart_writeX('\r');
				show_device_name();
				break;
		
			case 'L':			// | Leave programming mode            	| 'L' |       |      | 13d |   5  |
				tpi_leave_programming_mode();
				uart_writeX('\r');
				break;
		
			case 'a':			// | Report autoincrement address      	| 'a' |       | 	 | 'Y' |      |
				uart_writeX('Y');
				break;
		
			case 'A':			// | Set address                       	| 'A' | ah al |      | 13d |   2  |
				// word address for flash
				address=(((uart_read_q()<<8)|uart_read_q())<<1)+target_avr.flash_offset;
				write_nvm_address(address);
				uart_writeX('\r');
				break;
		
			case 'c':			// | Write program memory, low byte    	| 'c' |    dd |      | 13d |   3  |
				write_nvm_command(NVMCMD_MEMORY_WRITE);
				write_tpi_q(SST_POSTINC);
				write_tpi_q(uart_read_q());
				uart_writeX('\r');
				break;
			
			case 'C':			// | Write program memory, high byte   	| 'C' |    dd |      | 13d |   3  |
				write_tpi_q(SST_POSTINC);
				write_tpi_q(uart_read_q());
				address+=2; // auto-increment on high byte only
				flash_byte_count+=2;
				while(nvm_busy());
				uart_writeX('\r');
				break;
		
			case 'R':			// | Read program memory               	| 'R' |       |dd(dd)|     |   4  |
				write_nvm_command(NVMCMD_MEMORY_WRITE);

				save_byte = read_nvm_byte(); 
				uart_writeX(read_nvm_byte()); // high byte first
				uart_writeX(save_byte); // then low byte

//				uart_writeX(read_nvm_byte()); // low byte first
//				uart_writeX(read_nvm_byte()); // high byte first

				address+=2;  // auto-increment
			break;
			
			case 'e':			// | Chip erase                        	| 'e' |       |      | 13d |      |
				write_nvm_address(NVM_PROG_MEM_START);
				write_nvm_command(NVMCMD_CHIP_ERASE);
				write_nvm_word(0xFFFF);
				while(nvm_busy());
				uart_writeX('\r');
				break;
		
			case 'b':   		// | check block support							| 'b' |       |dd dd |  Y  |      |
				uart_writeX('Y');
//				if(get_signature()==TPI_OK){
//					uart_writeX(target_avr.page_size>>8);
//					uart_writeX(target_avr.page_size&0xFF);
					uart_writeX(0);
					uart_writeX(64);
//				}
				break;

			case 'B':	  		// | flash or eeprom block write		| 'B' |dd(dd) |      | 13d |   	   |
				// get the byte count for this block
				byte_count = ((uart_read_q()<<8) | uart_read_q());
				// is it for flash or eeprom?
				mem_type = uart_read_q();
				if(mem_type == MEMORY_TYPE_FLASH){
					write_nvm_command(NVMCMD_MEMORY_WRITE);
					for(uint16_t i=0;i<byte_count;i+=2){
						// write low byte
						write_tpi_q(SST_POSTINC);
						write_tpi_q(uart_read_q());
						// write high byte
						write_tpi_q(SST_POSTINC);
						write_tpi_q(uart_read_q());
						address++; // auto-increment on high byte only
						flash_byte_count++;
						while(nvm_busy());
						}
					}else{ 
						// no eeprom on TPI tiny's, ignore
						for(uint16_t i=0;i<byte_count;i++){
							uart_read_q();
						}
					}
				// tell host we're ready for next block
				uart_writeX('\r');
				break;
			
			case 'g':				// | flash or eeprom block read			| 'g' |       |dd(dd)|     |      |
				// get byte count to read for this block
				byte_count=(uart_read_q()<<8)|uart_read_q();
				// get memory type - flash or eeprom
				if(uart_read_q()==MEMORY_TYPE_FLASH){
					write_nvm_command(NVMCMD_MEMORY_WRITE);
					for(uint16_t i=0;i<byte_count;i+=2){
						// read and send all the bytes for this block
						// using a byte address to read. <<1 converts
						// the word address to a byte address.

//						save_byte = read_nvm_byte(); // low byte
//						uart_writeX(read_nvm_byte()); // high byte
//						uart_writeX(save_byte); // low byte

						save_byte = read_nvm_byte(); // low byte
						uart_writeX(save_byte); // low byte
						uart_writeX(read_nvm_byte()); // high byte
						// and auto-increment flash word address	
						address+=(byte_count>>1);
					}
				}else{
					// byte address given for eeprom
					for(uint16_t i=0;i<byte_count;i++){
						// no eeprom on TPI tiny's
						uart_writeX(0x00);
					}
				}
				break;

			case 'f':			// | Write fuse bits                		| 'f' |    dd |      | 13d |  11  |
				// erase first
				write_nvm_command((uint8_t)NVMCMD_SECTION_ERASE);
				write_nvm_address(CONF_BITS_START);
				write_nvm_word(0xFFFF);
				while(nvm_busy());
				// then write new value
				write_nvm_command(NVMCMD_MEMORY_WRITE);
				write_nvm_address(CONF_BITS_START);
				write_nvm_word(0xFF00 | uart_read_q());
				while(nvm_busy());
				uart_writeX('\r');
				break;

			case 'F':			// | Read fuse bits			      					| 'F' |       |   dd |     |  11  |
				write_nvm_address(CONF_BITS_START);
				uart_writeX(read_nvm_byte());
				break;

			case 'l':   		// | Write lock bits      						| 'l' |    dd |      | 13d |  14  |
				// erase first
				write_nvm_command((uint8_t)NVMCMD_SECTION_ERASE);
				write_nvm_address(NVM_LOCK_BITS_START);
				write_nvm_word(0xFFFF);
				while(nvm_busy());
				// then write new value
				write_nvm_command(NVMCMD_MEMORY_WRITE);
				write_nvm_address(NVM_LOCK_BITS_START);
				write_nvm_word(0xFF00 | uart_read_q());
				while(nvm_busy());
				uart_writeX('\r');
				break;
					
			case 'r':   		// | Read lock bits										| 'r' |       |   dd |     |  14  |
				write_nvm_address(NVM_LOCK_BITS_START);
				uart_writeX(read_nvm_byte());
				break;

			case 'T':			// | Select device type                	| 'T' |    dd |      | 13d |   6  |
				// read and ignore since we already know our
				// device type.
				uart_read_q(); 
				uart_writeX('\r');
				break;
		

			case 's':			// | Read signature bytes              	| 's' |       | 3*dd |     |      |
//				if(get_signature()==TPI_OK){
					uart_writeX(target_avr.signature[2]);
					uart_writeX(target_avr.signature[1]);
					uart_writeX(target_avr.signature[0]);
//				}
//				show_device_name();
				break;
		
			case 't':			// | Return supported device codes     	| 't' |       | n*dd | 00d |   7  |
				// only give the one we are going to program because
				// avrdude avr910 code is a little screwed up and will
				// always pick the 1st device we would send. So, make
				// it easy for avrdude, only send the one.
//				if(get_signature()==TPI_OK)
				for(uint8_t i=0;i<DEVICE_COUNT;i++){
					uart_writeX(pgm_read_byte_near((char*)&avr_info[i].device_code));
				}
				uart_writeX(0x00);
				break;
		
			case 'S':			// | Return software identifier        	| 'S' |       | s[7] |     |   8  |
				uart_write_PSTR(PSTR(PROGRAMMER_ID));
				break;
		
			case 'V':			// | Return sofware version            	| 'V' |       |dd dd |     |   9  |
				uart_write_PSTR(PSTR(SOFTWARE_VERSION));
				break;
		
			case 'v':			// | Return hardware version           	| 'v' |       |dd dd |     |   9  |
				uart_write_PSTR(PSTR(HARDWARE_VERSION));
				break;

			case'p':			// | Return programmer type            	| 'p' |       |   dd |     |  10  |
				uart_writeX('S');
				break;
		
			case '.':			// | New universal command	       			| '.' |  4*dd |   dd | 13d |      |
				// Used for non-blocked read/write memories
				u_cmd = (uart_read_q()<<8) | uart_read_q();
				fprintf_P(&lcd_stream, PSTR("%04X"),u_cmd);

				switch(u_cmd){
					case 0x5000: // read fuse
						universal_read_fuse(CONF_BITS_START);
						break;
					case 0xACA8: // write fuse
						universal_write_fuse(CONF_BITS_START);
						break;

					case 0x5800: // read lock
						universal_read_fuse(NVM_LOCK_BITS_START);
						break;
					case 0xACE0: // write lock
						universal_write_fuse(NVM_LOCK_BITS_START);
						break;

					case 0x3800: // read calibration
						universal_read_fuse(CALIB_BITS_START);
						break;

					case 0x3000: // read signature
						u_offset = uart_read_q();
						uart_read_q();
						write_nvm_address(DEV_ID_START + u_offset);
						uart_writeX(read_nvm_byte());
						uart_writeX('\r');
						break;

					default:
						uart_writeX('?');
						break;
				}


				break;
		
			case 'E':			// | Exit bootloader		       					| 'E' |       |      | 13d |      |
				// avrdude gives an error message if we don't do this
				tpi_leave_programming_mode();
				uart_writeX('\r');
				break;
		
			case 0x1B:			// | ESC - sync char	       					| x1B |   dd  |      |     |      |
				// consume, no reply
				break;

			default:			// | Unknown command	       					|     |       |      |  ?  |      |
				fprintf_P(&lcd_stream, PSTR("?%%%02X"), (uint8_t) command);
				uart_writeX('?');
				break;
		}
	CDC_Device_USBTask(&VirtualSerial_CDC_Interface);

	}
}

/** Event handler for the library USB Configuration Changed event. */
void EVENT_USB_Device_ConfigurationChanged(void)
{
	CDC_Device_ConfigureEndpoints(&VirtualSerial_CDC_Interface);
}

/** Event handler for the library USB Control Request reception event. */
void EVENT_USB_Device_ControlRequest(void)
{
	CDC_Device_ProcessControlRequest(&VirtualSerial_CDC_Interface);
}
