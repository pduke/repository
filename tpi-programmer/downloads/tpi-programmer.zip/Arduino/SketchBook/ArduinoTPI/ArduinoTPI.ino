// ArduinoTPI version 01.1 (based on ArduinoISP)
// Copyright (c) 2014 Paul Duke
// If you require a license, see 
//     http://www.opensource.org/licenses/bsd-license.php
//
// This sketch turns the Arduino UNO into a TPI programmer
// using the following arduino pins:
//
// June 2014 Paul Duke
// - initial release
//
//
#include "pins_arduino.h"
//
// TPI pins
#define RESET       9
#define TPI_CLK     8
#define TPI_DATA   10
//
// Programmer status LED's:
#define LED_HB        3  // Heartbeat (GREEN)    - shows the programmer is running (switched from pin 9 to free timer1)
#define LED_ERR       8  // Error (RED)          - Lights up if something goes wrong (use red if that makes sense)
#define LED_PMODE     7  // Programming (BLUE)   - In communication with the slave
#define PROG_FLICKER  true

// STK versions
#define HWVER 2
#define SWMAJ 1
#define SWMIN 18

// STK Definitions
#define STK_OK      0x10
#define STK_FAILED  0x11
#define STK_UNKNOWN 0x12
#define STK_INSYNC  0x14
#define STK_NOSYNC  0x15
#define CRC_EOP     0x20 //ok it is a space...

#define SERIAL_DEBUG true

void pulse(int pin, int times);

void setup() {
  delay(500);
  Serial.begin(115200);
  if (SERIAL_DEBUG) Serial.println("Ready");


  // reduce serial error with U2X - atmega328p spec 19.11 Examples of Baud Rate Setting
  //UCSR0A = _BV(U2X0);
  //unsigned int baud_setting = (F_CPU / 4 / 115200L - 1) / 2;
  //UBRR0 = baud_setting;

  pinMode(LED_PMODE, OUTPUT);
  pulse(LED_PMODE, 2);
  pinMode(LED_ERR, OUTPUT);
  pulse(LED_ERR, 2);
  pinMode(LED_HB, OUTPUT);
  pulse(LED_HB, 2);

  cli();          // disable global interrupts

  // set up timer1 for heartbeat
  TCCR1A = 0;     // set entire TCCR1A register to 0
  TCCR1B = 0;     // same for TCCR1B
  // set compare match register to desired timer count:
  OCR1A = 625; // 40ms
  // turn on CTC mode:
  TCCR1B |= _BV(WGM12);
  // Set CS10 and CS12 bits for 1024 prescaler:
  TCCR1B |= _BV(CS10);
  TCCR1B |= _BV(CS12);
  // enable timer compare interrupt:
  TIMSK1 |= _BV(OCIE1A);

  // setup timer2 as TPI clock
  TIMSK2 |= _BV(OCIE2A) | _BV(TOV2);
  OCR2A = 128;

  sei();          // enable global interrupts  
  if (SERIAL_DEBUG) Serial.println("Starting");
}

// timer1 provides a heartbeat on LED_HB, so you can tell the software is running.
// and flicker of program mode led during activity
volatile uint8_t hbval=128;
volatile int8_t hbdelta=8;
int error=0;
volatile int pmode=0;

#define FLICKER_ON 1
#define FLICKER_RESET FLICKER_ON<<1
volatile boolean flicker_sw = false;
volatile uint8_t flicker_time = 0;
ISR(TIMER1_COMPA_vect)
{
  if (hbval > 192) hbdelta = -hbdelta;
  if (hbval < 20) hbdelta = -hbdelta;
  hbval += hbdelta;
  analogWrite(LED_HB, hbval);

  if(pmode && flicker_sw){
    if(flicker_time == 0) digitalWrite(LED_PMODE, LOW);
    if(flicker_time == FLICKER_ON) digitalWrite(LED_PMODE, HIGH);
    if(flicker_time == FLICKER_RESET){
      flicker_time = 0;
      flicker_sw = false;
    } 
    else {
      flicker_time++;
    }
  }

  if (error) {
    if (digitalRead(LED_ERR)==LOW && SERIAL_DEBUG) Serial.println("LED_ERR on");
    digitalWrite(LED_ERR, HIGH);
  }
  else {
    if (digitalRead(LED_ERR)==HIGH && SERIAL_DEBUG) Serial.println("LED_ERR off");
    digitalWrite(LED_ERR, LOW);
  }
}

// address for reading and writing, set by 'U' command
int here;

// big endian conversions
uint16_t beget16(uint16_t i){
  uint16_t ibe;
  ibe = (i<<8) | (i>>8);
  return ibe;
}

uint32_t beget32(uint32_t i){
  uint32_t ibe;
  ibe = ((i>>24)&0xff) | ((i<<8)&0xff0000) | ((i>>8)&0xff00) | ((i<<24)&0xff000000);
  return ibe;
}

typedef struct param {
  uint8_t devicecode;
  uint8_t revision;
  uint8_t progtype;
  uint8_t parmode;
  uint8_t polling;
  uint8_t selftimed;
  uint8_t lockbytes;
  uint8_t fusebytes;
  int16_t flashpoll;
  int16_t eeprompoll;
  int16_t pagesize;
  int16_t eepromsize;
  int32_t flashsize;
} 
parameter;

parameter param;

void loop(void) {
  avrtpi();
}

uint8_t getch() {
  while(!Serial.available());
  return Serial.read();
}

#define PTIME 30
void pulse(int pin, int times) {
  do {
    digitalWrite(pin, HIGH);
    delay(PTIME);
    digitalWrite(pin, LOW);
    delay(PTIME);
  } 
  while (times--);
}

void spi_init() {
  uint8_t x;
  SPCR = 0x53;
  x=SPSR;
  x=SPDR;
}

void spi_wait() {
  do {
  } 
  while (!(SPSR & (1 << SPIF)));
}

uint8_t spi_send(uint8_t b) {
  uint8_t reply;
  SPDR=b;
  spi_wait();
  reply = SPDR;
  return reply;
}

// wait on previous spi command to complete rather than use delay's
void wait_AVR_Busy(void){
  uint8_t bsy = 0x01;
  while(bsy) {
    spi_send(0xF0); 
    spi_send(0x00); 
    spi_send(0x00); 
    bsy = spi_send(0x00) & 0x01; 
  }
}	

uint8_t spi_transaction(uint8_t a, uint8_t b, uint8_t c, uint8_t d) {
  uint8_t n;
  wait_AVR_Busy();
  spi_send(a); 
  n=spi_send(b);
  if (n != a) error++;
  n=spi_send(c);
  return spi_send(d);
}

void empty_reply() {
  if (CRC_EOP == getch()) {
    Serial.print((char)STK_INSYNC);
    Serial.print((char)STK_OK);
  } 
  else {
    error++;
    Serial.print((char)STK_NOSYNC);
  }
}

void breply(uint8_t b) {
  if (CRC_EOP == getch()) {
    Serial.print((char)STK_INSYNC);
    Serial.print((char)b);
    Serial.print((char)STK_OK);
  } 
  else {
    error++;
    Serial.print((char)STK_NOSYNC);
  }
}

void get_version(uint8_t c) {
  switch(c) {
  case 0x80:
    breply(HWVER);
    break;
  case 0x81:
    breply(SWMAJ);
    break;
  case 0x82:
    breply(SWMIN);
    break;
  case 0x93:
    breply('S'); // serial programmer
    break;
  default:
    breply(0);
  }
}

void start_pmode() {
  spi_init();
  // following delays may not work on all targets...
  pinMode(RESET, OUTPUT);
  pinMode(SCK, OUTPUT);
  pinMode(MISO, INPUT);
  pinMode(MOSI, OUTPUT);
  digitalWrite(RESET, HIGH);
  digitalWrite(SCK, LOW);
  delay(1);
  digitalWrite(RESET, LOW);
  delay(50);
  spi_transaction(0xAC, 0x53, 0x00, 0x00);
  pmode = 1;
  digitalWrite(LED_PMODE, HIGH);
}

void end_pmode() {
  SPCR = 0;
  pinMode(MISO, INPUT);
  pinMode(MOSI, INPUT);
  pinMode(SCK, INPUT);
  pinMode(RESET, INPUT);
  pmode = 0;
  digitalWrite(LED_PMODE, LOW);
}

void universal() {
  flicker_sw = true;
  uint8_t ch;
  ch = spi_transaction(getch(), getch(), getch(), getch());
  breply(ch);
}

void flash(uint8_t hilo, int addr, uint8_t data) {
  flicker_sw = true;
  spi_transaction(0x40+8*hilo, 
  addr>>8 & 0xFF, 
  addr & 0xFF,
  data);
}

void commit(int addr) {
  flicker_sw = true;
  spi_transaction(0x4C, (addr >> 8) & 0xFF, addr & 0xFF, 0);
}

int current_page(int addr) {
  if (param.pagesize == 32)  return here & 0xFFFFFFF0;
  if (param.pagesize == 64)  return here & 0xFFFFFFE0;
  if (param.pagesize == 128) return here & 0xFFFFFFC0;
  if (param.pagesize == 256) return here & 0xFFFFFF80;
  return here;
}

char rxBuff[256];

void write_flash(int length) {
  flicker_sw = true;
  int x = 0;
  int page = current_page(here);
  if(Serial.readBytes(rxBuff, length) != (unsigned) length) error++;
  while (x < length) {
    if (page != current_page(here)) {
      commit(page);
      page = current_page(here);
    }
    flash(LOW, here, rxBuff[x++]);
    flash(HIGH, here, rxBuff[x++]);
    here++;
  }
  commit(page);
  if (CRC_EOP == getch()) {
    Serial.print((char) STK_INSYNC);
    Serial.print((char) STK_OK);
  } 
  else {
    error++;
    Serial.print((char) STK_NOSYNC);
  }
}

#define EECHUNK (32)
uint8_t write_eeprom(int length) {
  // here is a word address, get the byte address
  flicker_sw = true;
  int start = here * 2;
  int remaining = length;
  if (length > param.eepromsize) {
    error++;
    return STK_FAILED;
  }
  while (remaining > EECHUNK) {
    write_eeprom_chunk(start, EECHUNK);
    start += EECHUNK;
    remaining -= EECHUNK;
  }
  write_eeprom_chunk(start, remaining);
  return STK_OK;
}

// write (length) bytes, (start) is a byte address
uint8_t write_eeprom_chunk(int start, int length) {
  // this writes byte-by-byte,
  // page writing may be faster (4 bytes at a time)
  flicker_sw = true;
  if(Serial.readBytes(rxBuff, length) != (unsigned)length) error++;
  for (int x = 0; x < length; x++) {
    int addr = start+x;
    spi_transaction(0xC0, (addr>>8) & 0xFF, addr & 0xFF, rxBuff[x]);
  }
  return STK_OK;
}

void program_page() {
  flicker_sw = true;
  char result = (char) STK_FAILED;
  int length = 256 * getch();
  length += getch();
  char memtype = getch();
  // flash memory @here, (length) bytes
  if (memtype == 'F') {
    write_flash(length);
    return;
  }
  if (memtype == 'E') {
    result = (char)write_eeprom(length);
    if (CRC_EOP == getch()) {
      Serial.print((char) STK_INSYNC);
      Serial.print(result);
    } 
    else {
      error++;
      Serial.print((char) STK_NOSYNC);
    }
    return;
  }
  Serial.print((char)STK_FAILED);
  return;
}

uint8_t flash_read(uint8_t hilo, int addr) {
  flicker_sw = true;
  return spi_transaction(0x20 + hilo * 8,
  (addr >> 8) & 0xFF,
  addr & 0xFF,
  0);
}

char flash_read_page(int length) {
  flicker_sw = true;
  for (int x = 0; x < length; x+=2) {
    uint8_t low = flash_read(LOW, here);
    Serial.print((char) low);
    uint8_t high = flash_read(HIGH, here);
    Serial.print((char) high);
    here++;
  }
  return STK_OK;
}

char eeprom_read_page(int length) {
  flicker_sw = true;
  // here again we have a word address
  int start = here * 2;
  for (int x = 0; x < length; x++) {
    int addr = start + x;
    uint8_t ee = spi_transaction(0xA0, (addr >> 8) & 0xFF, addr & 0xFF, 0xFF);
    Serial.print((char) ee);
  }
  return STK_OK;
}

void read_page() {
  flicker_sw = true;
  char result = (char)STK_FAILED;
  int length = 256 * getch();
  length += getch();
  char memtype = getch();
  if (CRC_EOP != getch()) {
    error++;
    Serial.print((char) STK_NOSYNC);
    return;
  }
  Serial.print((char) STK_INSYNC);
  if (memtype == 'F') result = flash_read_page(length);
  if (memtype == 'E') result = eeprom_read_page(length);
  Serial.print(result);
  return;
}

void read_signature() {
  flicker_sw = true;
  if (CRC_EOP != getch()) {
    error++;
    Serial.print((char) STK_NOSYNC);
    return;
  }
  Serial.print((char) STK_INSYNC);
  uint8_t high = spi_transaction(0x30, 0x00, 0x00, 0x00);
  Serial.print((char) high);
  uint8_t middle = spi_transaction(0x30, 0x00, 0x01, 0x00);
  Serial.print((char) middle);
  uint8_t low = spi_transaction(0x30, 0x00, 0x02, 0x00);
  Serial.print((char) low);
  Serial.print((char) STK_OK);
}

//////////////////////////////////////////                                      //////////////////////////////////////////
//////////////////////////////////////////                                      //////////////////////////////////////////
void avrtpi() {
  //  uint8_t i;
  uint8_t ch = getch();
  if (SERIAL_DEBUG) Serial.println(ch);
  switch (ch) {

  case '0': // signon
    error = 0;
    empty_reply();
    break;

  case '1':
    if (getch() == CRC_EOP) {
      Serial.print((char) STK_INSYNC);
      Serial.print("AVR ISP");
      Serial.print((char) STK_OK);
    }
    break;

  case 'A':
    get_version(getch());
    break;

  case 'B':
    if(Serial.readBytes((char *)(&param), sizeof(param)) != sizeof(param)) error++;
    //      for(i=0;i<sizeof(param);i++) ((uint8_t*)(&param))[i] = getch();
    param.flashpoll = beget16(param.flashpoll);
    param.eeprompoll = beget16(param.eeprompoll);
    param.pagesize = beget16(param.pagesize);
    param.eepromsize = beget16(param.eepromsize);
    param.flashsize = beget32(param.flashsize);
    empty_reply();
    break;

  case 'E': // extended parameters - ignore for now
    for(int tmp = 0; tmp < 5; tmp++) getch();
    empty_reply();
    break;

  case 'P':
    start_pmode();
    empty_reply();
    break;

  case 'U': // set address (word)
    here = getch();
    here += 256 * getch();
    empty_reply();
    break;

  case 0x64: // STK_PROG_PAGE 'd'
    program_page();
    break;

  case 0x74: // STK_READ_PAGE 't'
    read_page();    
    break;

  case 'V': //0x56
    flicker_sw = true;
    universal();
    break;

  case 'Q': //0x51
    error=0;
    end_pmode();
    empty_reply();
    break;

  case 0x75: //STK_READ_SIGN 'u'
    read_signature();
    break;
    // expecting a command, not CRC_EOP
    // this is how we can get back in sync

  case CRC_EOP:
    error++;
    Serial.print((char) STK_NOSYNC);
    break;
    // anything else will return STK_UNKNOWN

  default:
    // unimplemented command or anything else is unknown  
  case 0x60: //STK_PROG_FLASH
  case 0x61: //STK_PROG_DATA
    if(pmode) error++;
    Serial.print((char)STK_UNKNOWN);
    break;
  }
}







