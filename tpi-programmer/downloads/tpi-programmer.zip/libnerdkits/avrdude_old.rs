	# $Id: avrdude.conf.in,v 1.140 2009/02/26 19:43:54 joerg_wunsch Exp $
	#
	# AVRDUDE Configuration File
	#
	# This file contains configuration data used by AVRDUDE which describes
	# the programming hardware pinouts and also provides part definitions.
	# AVRDUDE's "-C" command line option specifies the location of the
	# configuration file.  The "-c" option names the programmer configuration
	# which must match one of the entry's "id" parameter.  The "-p" option
	# identifies which part AVRDUDE is going to be programming and must match
	# one of the parts' "id" parameter.
	#

	# Overall avrdude defaults
	#
	default_parallel   = "lpt1";
	default_serial     = "\dev\ttyUSB0";

	#
	# PROGRAMMER DEFINITIONS
	#
	programmer
	  id    = "AVRBOOT";
	  desc  = "Noter's AVR bootloader";
	  baudrate = 115200;
	  type  = butterfly;
	;

	programmer
	  id    = "avr109";
	  desc  = "Nerdkit's foodloader";
	  baudrate = 115200;
	  type  = butterfly;
	;

	programmer
	  id    = "AVR ISP";
	  desc  = "Noter's AVR SPI programmer";
	  baudrate = 115200;
	  type  = avr910;
	;

	programmer
	  id    = "NANOISP";
	  desc  = "Noter's AVR SPI programmer";
	  baudrate = 115200;
	  type  = avr910;
	;

	programmer
	  id    = "AVR TPI";
	  desc  = "Noter's AVR TPI programmer";
	  baudrate = 115200;
	  type  = avr910;
	;

	programmer
	  id    = "USB_TPI";
	  desc  = "Noter's USB_TPI programmer";
	  baudrate = 115200;
	  type  = avr910;
	;

	programmer
	  id    = "AVR HV ";
	  desc  = "Noter's AVR High Voltage programmer";
	  baudrate = 250000;
	  type  = avr910;
	;

	programmer
		id    = "avrisp";
		desc  = "Atmel AVR ISP";
	  type  = avr910;
	;



	#
	# PART DEFINITIONS
	#

	#------------------------------------------------------------
	# ATmega168
	#------------------------------------------------------------

	part
		id              = "atmega168";
		desc            = "ATMEGA168";
		has_debugwire = yes;
		flash_instr   = 0xB6, 0x01, 0x11;
		eeprom_instr  = 0xBD, 0xF2, 0xBD, 0xE1, 0xBB, 0xCF, 0xB4, 0x00,
				0xBE, 0x01, 0xB6, 0x01, 0xBC, 0x00, 0xBB, 0xBF,
				0x99, 0xF9, 0xBB, 0xAF;
		stk500_devcode = 0x02;
		avr910_devcode = 0x02;
		signature       = 0x1e 0x94 0x06;
		pagel           = 0xd7;
		bs2             = 0xc2;
		chip_erase_delay = 9000;
		pgm_enable       = "1 0 1 0 1 1 0 0 0 1 0 1 0 0 1 1",
						   "x x x x x x x x x x x x x x x x";

		chip_erase       = "1 0 1 0 1 1 0 0 1 0 0 x x x x x",
						   "x x x x x x x x x x x x x x x x";

		timeout         = 200;
		stabdelay       = 100;
		cmdexedelay     = 25;
		synchloops      = 32;
		bytedelay       = 0;
		pollindex       = 3;
		pollvalue       = 0x53;
		predelay        = 1;
		postdelay       = 1;
		pollmethod      = 1;

		pp_controlstack     =
		0x0E, 0x1E, 0x0F, 0x1F, 0x2E, 0x3E, 0x2F, 0x3F,
		0x4E, 0x5E, 0x4F, 0x5F, 0x6E, 0x7E, 0x6F, 0x7F,
		0x66, 0x76, 0x67, 0x77, 0x6A, 0x7A, 0x6B, 0x7B,
		0xBE, 0xFD, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00;
		hventerstabdelay    = 100;
		progmodedelay       = 0;
		latchcycles         = 5;
		togglevtg           = 1;
		poweroffdelay       = 15;
		resetdelayms        = 1;
		resetdelayus        = 0;
		hvleavestabdelay    = 15;
		resetdelay          = 15;
		chiperasepulsewidth = 0;
		chiperasepolltimeout = 10;
		programfusepulsewidth = 0;
		programfusepolltimeout = 5;
		programlockpulsewidth = 0;
		programlockpolltimeout = 5;

		memory "eeprom"
			paged           = no;
			page_size       = 4;
			size            = 517;
			min_write_delay = 3600;
			max_write_delay = 18000;
			readback_p1     = 0xff;
			readback_p2     = 0xff;
			read            = " 1 0 1 0 0 0 0 0",
							  " 0 0 0 x x x x a8",
							  " a7 a6 a5 a4 a3 a2 a1 a0",
							  " o o o o o o o o";
		
			write           = " 1 1 0 0 0 0 0 0",
							  " 0 0 0 x x x x a8",
							  " a7 a6 a5 a4 a3 a2 a1 a0",
							  " i i i i i i i i";

		loadpage_lo	= "  1   1   0   0      0   0   0   1",
				  "  0   0   0   0      0   0   0   0",
				  "  0   0   0   0      0   0  a1  a0",
				  "  i   i   i   i      i   i   i   i";

		writepage	= "  1   1   0   0      0   0   1   0",
				  "  0   0   x   x      x   x   x  a8",
				  " a7  a6  a5  a4     a3  a2   0   0",
				  "  x   x   x   x      x   x   x   x";

		mode		= 0x41;
		delay		= 5;
		blocksize	= 4;
		readsize	= 256;
			;

		memory "flash"
			paged           = yes;
			size            = 16384;
			page_size       = 128;
			num_pages       = 128;
			min_write_delay = 4500;
			max_write_delay = 4500;
			readback_p1     = 0xff;
			readback_p2     = 0xff;
			read_lo         = " 0 0 1 0 0 0 0 0",
							  " 0 0 0 a12 a11 a10 a9 a8",
							  " a7 a6 a5 a4 a3 a2 a1 a0",
							  " o o o o o o o o";
			
			read_hi          = " 0 0 1 0 1 0 0 0",
							   " 0 0 0 a12 a11 a10 a9 a8",
							   " a7 a6 a5 a4 a3 a2 a1 a0",
							   " o o o o o o o o";
			
			loadpage_lo     = " 0 1 0 0 0 0 0 0",
							  " 0 0 0 x x x x x",
							  " x x a5 a4 a3 a2 a1 a0",
							  " i i i i i i i i";
			
			loadpage_hi     = " 0 1 0 0 1 0 0 0",
							  " 0 0 0 x x x x x",
							  " x x a5 a4 a3 a2 a1 a0",
							  " i i i i i i i i";
			
			writepage       = " 0 1 0 0 1 1 0 0",
							  " 0 0 0 a12 a11 a10 a9 a8",
							  " a7 a6 x x x x x x",
							  " x x x x x x x x";

			mode        = 0x41;
			delay       = 6;
			blocksize   = 128;
			readsize    = 256;

			;
			
		memory "lfuse"
			size            = 1;
			min_write_delay = 4500;
			max_write_delay = 4500;
			read            = "0 1 0 1 0 0 0 0 0 0 0 0 0 0 0 0",
							  "x x x x x x x x o o o o o o o o";
			
			write           = "1 0 1 0 1 1 0 0 1 0 1 0 0 0 0 0",
							  "x x x x x x x x i i i i i i i i";
			;
		
		memory "hfuse"
			size            = 1;
			min_write_delay = 4500;
			max_write_delay = 4500;
			read            = "0 1 0 1 1 0 0 0 0 0 0 0 1 0 0 0",
							  "x x x x x x x x o o o o o o o o";
			
			write           = "1 0 1 0 1 1 0 0 1 0 1 0 1 0 0 0",
							  "x x x x x x x x i i i i i i i i";
			;
		
		memory "efuse"
			size            = 1;
			min_write_delay = 4500;
			max_write_delay = 4500;
			read            = "0 1 0 1 0 0 0 0 0 0 0 0 1 0 0 0",
			   "0 0 0 0 0 0 0 0 o o o o o o o o";
			
			write           = "1 0 1 0 1 1 0 0 1 0 1 0 0 1 0 0",
				"0 0 0 0 0 0 0 0 i i i i i i i i";
			;
		
		memory "lock"
			size            = 1;
			min_write_delay = 4500;
			max_write_delay = 4500;
			read            = "0 1 0 1 1 0 0 0 0 0 0 0 0 0 0 0",
			   "0 0 0 0 0 0 0 0 o o o o o o o o";
			
			write           = "1 0 1 0 1 1 0 0 1 1 1 x x x x x",
				"0 0 0 0 0 0 0 0 i i i i i i i i";
			;
		
		memory "calibration"
			size            = 1;
			read            = "0 0 1 1 1 0 0 0 0 0 0 x x x x x",
							  "0 0 0 0 0 0 0 0 o o o o o o o o";
			;
		
		memory "signature"
			size            = 3;
			read            = "0 0 1 1 0 0 0 0 0 0 0 x x x x x",
							  "x x x x x x a1 a0 o o o o o o o o";
			;
	;


	#------------------------------------------------------------
	# ATmega328P
	#------------------------------------------------------------

	part
		id			= "atmega328p";
		desc		= "ATMEGA328";
		has_debugwire	= yes;
		flash_instr		= 0xB6, 0x01, 0x11;
		eeprom_instr	= 0xBD, 0xF2, 0xBD, 0xE1, 0xBB, 0xCF, 0xB4, 0x00,
				0xBE, 0x01, 0xB6, 0x01, 0xBC, 0x00, 0xBB, 0xBF,
				0x99, 0xF9, 0xBB, 0xAF;
		stk500_devcode = 0x03;
		avr910_devcode = 0x03;
		signature		= 0x1e 0x95 0x0F;
		pagel		= 0xd7;
		bs2			= 0xc2;
		chip_erase_delay	= 9000;
		pgm_enable = "1 0 1 0 1 1 0 0 0 1 0 1 0 0 1 1",
			 "x x x x x x x x x x x x x x x x";

		chip_erase = "1 0 1 0 1 1 0 0 1 0 0 x x x x x",
			 "x x x x x x x x x x x x x x x x";

		timeout	= 200;
		stabdelay	= 100;
		cmdexedelay	= 25;
		synchloops	= 32;
		bytedelay	= 0;
		pollindex	= 3;
		pollvalue	= 0x53;
		predelay	= 1;
		postdelay	= 1;
		pollmethod	= 1;

		pp_controlstack =
		0x0E, 0x1E, 0x0F, 0x1F, 0x2E, 0x3E, 0x2F, 0x3F,
		0x4E, 0x5E, 0x4F, 0x5F, 0x6E, 0x7E, 0x6F, 0x7F,
		0x66, 0x76, 0x67, 0x77, 0x6A, 0x7A, 0x6B, 0x7B,
		0xBE, 0xFD, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00;
		hventerstabdelay	= 100;
		progmodedelay	= 50;
		latchcycles		= 5;
		togglevtg		= 1;
		poweroffdelay	= 15;
		resetdelayms	= 1;
		resetdelayus	= 0;
		hvleavestabdelay	= 15;
		resetdelay		= 15;
		chiperasepulsewidth	= 0;
		chiperasepolltimeout = 10;
		programfusepulsewidth = 0;
		programfusepolltimeout = 5;
		programlockpulsewidth = 0;
		programlockpolltimeout = 5;

		memory "eeprom"
		paged		= no;
		page_size	= 4;
		size		= 1029;
		min_write_delay = 3600;
		max_write_delay = 18000;
		readback_p1	= 0xff;
		readback_p2	= 0xff;
		read = " 1 0 1 0 0 0 0 0",
			   " 0 0 0 x x x a9 a8",
			   " a7 a6 a5 a4 a3 a2 a1 a0",
			   " o o o o o o o o";

		write = " 1 1 0 0 0 0 0 0",
				" 0 0 0 x x x a9 a8",
			" a7 a6 a5 a4 a3 a2 a1 a0",
			" i i i i i i i i";

		loadpage_lo = " 1 1 0 0 0 0 0 1",
				  " 0 0 0 0 0 0 0 0",
				  " 0 0 0 0 0 0 a1 a0",
				  " i i i i i i i i";

		writepage = " 1 1 0 0 0 0 1 0",
				" 0 0 x x x x a9 a8",
				" a7 a6 a5 a4 a3 a2 0 0",
				" x x x x x x x x";

		mode		= 0x41;
		delay		= 5;
		blocksize	= 4;
		readsize	= 256;
		;

		memory "flash"
		paged		= yes;
		size		= 32768;
		page_size	= 128;
		num_pages	= 256;
		min_write_delay = 4500;
		max_write_delay = 4500;
		readback_p1	= 0xff;
		readback_p2	= 0xff;
		read_lo = " 0 0 1 0 0 0 0 0",
			  " 0 0 a13 a12 a11 a10 a9 a8",
			  " a7 a6 a5 a4 a3 a2 a1 a0",
			  " o o o o o o o o";

		read_hi = " 0 0 1 0 1 0 0 0",
			  " 0 0 a13 a12 a11 a10 a9 a8",
			  " a7 a6 a5 a4 a3 a2 a1 a0",
			  " o o o o o o o o";

		loadpage_lo = " 0 1 0 0 0 0 0 0",
				  " 0 0 0 x x x x x",
				  " x x a5 a4 a3 a2 a1 a0",
				  " i i i i i i i i";

		loadpage_hi = " 0 1 0 0 1 0 0 0",
				  " 0 0 0 x x x x x",
				  " x x a5 a4 a3 a2 a1 a0",
				  " i i i i i i i i";

		writepage = " 0 1 0 0 1 1 0 0",
				" 0 0 a13 a12 a11 a10 a9 a8",
				" a7 a6 x x x x x x",
				" x x x x x x x x";

		mode		= 0x41;
		delay		= 6;
		blocksize	= 128;
		readsize	= 256;

		;

		memory "lfuse"
		size = 1;
		min_write_delay = 4500;
		max_write_delay = 4500;
		read = "0 1 0 1 0 0 0 0 0 0 0 0 0 0 0 0",
			   "x x x x x x x x o o o o o o o o";

		write = "1 0 1 0 1 1 0 0 1 0 1 0 0 0 0 0",
				"x x x x x x x x i i i i i i i i";
		;

		memory "hfuse"
		size = 1;
		min_write_delay = 4500;
		max_write_delay = 4500;
		read = "0 1 0 1 1 0 0 0 0 0 0 0 1 0 0 0",
			   "x x x x x x x x o o o o o o o o";

		write = "1 0 1 0 1 1 0 0 1 0 1 0 1 0 0 0",
				"x x x x x x x x i i i i i i i i";
		;

		memory "efuse"
		size = 1;
		min_write_delay = 4500;
		max_write_delay = 4500;
		read = "0 1 0 1 0 0 0 0 0 0 0 0 1 0 0 0",
			   "0 0 0 0 0 0 0 0 o o o o o o o o";

		write = "1 0 1 0 1 1 0 0 1 0 1 0 0 1 0 0",
				"0 0 0 0 0 0 0 0 i i i i i i i i";
		;

		memory "lock"
		size = 1;
		min_write_delay = 4500;
		max_write_delay = 4500;
		read = "0 1 0 1 1 0 0 0 0 0 0 0 0 0 0 0",
			   "0 0 0 0 0 0 0 0 o o o o o o o o";

		write = "1 0 1 0 1 1 0 0 1 1 1 0 0 0 0 0",
				"0 0 0 0 0 0 0 0 i i i i i i i i";
		;

		memory "calibration"
		size = 1;
		read = "0 0 1 1 1 0 0 0 0 0 0 x x x x x",
			   "0 0 0 0 0 0 0 0 o o o o o o o o";
		;

		memory "signature"
		size = 3;
		read = "0 0 1 1 0 0 0 0 0 0 0 x x x x x",
			   "x x x x x x a1 a0 o o o o o o o o";
		;

	;

	#------------------------------------------------------------
	# ATtiny85
	#------------------------------------------------------------

	part
		 id            = "attiny85";
		 desc          = "ATtiny85";
		 has_debugwire = yes;
		 flash_instr   = 0xB4, 0x02, 0x12;
		 eeprom_instr  = 0xBB, 0xFF, 0xBB, 0xEE, 0xBB, 0xCC, 0xB2, 0x0D,
					 0xBC, 0x02, 0xB4, 0x02, 0xBA, 0x0D, 0xBB, 0xBC,
					 0x99, 0xE1, 0xBB, 0xAC;
		stk500_devcode = 0x01;
		avr910_devcode = 0x01;
		 signature        = 0x1e 0x93 0x0b;
		 reset            = io;
		 chip_erase_delay = 4500;

		 pgm_enable       = "1 0 1 0  1 1 0 0    0 1 0 1  0 0 1 1",
							"x x x x  x x x x    x x x x  x x x x";

		 chip_erase       = "1 0 1 0  1 1 0 0    1 0 0 x  x x x x",
							"x x x x  x x x x    x x x x  x x x x";

		timeout		= 200;
		stabdelay		= 100;
		cmdexedelay		= 25;
		synchloops		= 32;
		bytedelay		= 0;
		pollindex		= 3;
		pollvalue		= 0x53;
		predelay		= 1;
		postdelay		= 1;
		pollmethod		= 1;

		hvsp_controlstack   =
			0x4C, 0x0C, 0x1C, 0x2C, 0x3C, 0x64, 0x74, 0x66,
			0x68, 0x78, 0x68, 0x68, 0x7A, 0x6A, 0x68, 0x78,
			0x78, 0x7D, 0x6D, 0x0C, 0x80, 0x40, 0x20, 0x10,
			0x11, 0x08, 0x04, 0x02, 0x03, 0x08, 0x04, 0x00;
		hventerstabdelay    = 100;
		hvspcmdexedelay     = 0;
		synchcycles         = 6;
		latchcycles         = 1;
		togglevtg           = 1;
		poweroffdelay       = 25;
		resetdelayms        = 1;
		resetdelayus        = 0;
		hvleavestabdelay    = 100;
		resetdelay          = 25;
		chiperasepolltimeout = 40;
		chiperasetime       = 0;
		programfusepolltimeout = 25;
		programlockpolltimeout = 25;

		 memory "eeprom"
			 size            = 512;
			paged           = no;
			page_size       = 4;
			 min_write_delay = 4000;
			 max_write_delay = 4500;
			 readback_p1     = 0xff;
			 readback_p2     = 0xff;
			 read            = "1  0  1  0   0  0  0  0    0 0 0 x  x x x a8",
							   "a7 a6 a5 a4  a3 a2 a1 a0   o o o o  o o o o";

			 write           = "1  1  0  0   0  0  0  0    0 0 0 x  x x x a8",
							   "a8 a6 a5 a4  a3 a2 a1 a0   i i i i  i i i i";

		loadpage_lo	= "  1   1   0   0      0   0   0   1",
				  "  0   0   0   0      0   0   0   0",
				  "  0   0   0   0      0   0  a1  a0",
				  "  i   i   i   i      i   i   i   i";

		writepage	= "  1   1   0   0      0   0   1   0",
				  "  0   0   x   x      x   x   x  a8",
				  " a7  a6  a5  a4     a3  a2   0   0",
				  "  x   x   x   x      x   x   x   x";

		mode		= 0x41;
		delay		= 6;
		blocksize	= 4;
		readsize	= 256;
		   ;
		 memory "flash"
			 paged           = yes;
			 size            = 8192;
			 page_size       = 64;
			 num_pages       = 128;
			 min_write_delay = 4500;
			 max_write_delay = 4500;
			 readback_p1     = 0xff;
			 readback_p2     = 0xff;
			 read_lo         = "  0   0   1   0    0   0   0   0",
							   "  0   0   0   0  a11 a10  a9  a8",
							   " a7  a6  a5  a4   a3  a2  a1  a0",
							   "  o   o   o   o    o   o   o   o";

			 read_hi         = "  0   0   1   0    1   0   0   0",
							   "  0   0   0   0  a11 a10  a9  a8",
							   " a7  a6  a5  a4   a3  a2  a1  a0",
							   "  o   o   o   o    o   o   o   o";

			 loadpage_lo     = "  0   1   0   0    0   0   0   0",
							   "  0   0   0   x    x   x   x   x",
							   "  x   x   x  a4   a3  a2  a1  a0",
							   "  i   i   i   i    i   i   i   i";

			 loadpage_hi     = "  0   1   0   0    1   0   0   0",
							   "  0   0   0   x    x   x   x   x",
							   "  x   x   x  a4   a3  a2  a1  a0",
							   "  i   i   i   i    i   i   i   i";

			 writepage       = "  0  1  0  0   1   1   0  0",
							   "  0  0  0  0  a11 a10 a9 a8",
							   " a7 a6 a5  x   x  x  x  x",
							   "  x  x  x  x   x  x  x  x";

		mode		= 0x41;
		delay		= 6;
		blocksize	= 32;
		readsize	= 256;
		   ;
		 memory "signature"
			 size            = 3;
			 read            = "0  0  1  1   0  0  0  0   0  0  0  x   x  x  x  x",
							   "x  x  x  x   x  x a1 a0   o  o  o  o   o  o  o  o";
		   ;
		 memory "lock"
			 size            = 1;
			 write           = "1 0 1 0  1 1 0 0  1 1 1 x  x x x x",
							   "x x x x  x x x x  1 1 i i  i i i i";
			min_write_delay = 9000;
			max_write_delay = 9000;
		   ;

		 memory "lfuse"
			 size            = 1;
			 write           = "1 0 1 0  1 1 0 0  1 0 1 0  0 0 0 0",
							   "x x x x  x x x x  i i i i  i i i i";

			 read            = "0 1 0 1  0 0 0 0  0 0 0 0  0 0 0 0",
							   "x x x x  x x x x  o o o o  o o o o";
			min_write_delay = 9000;
			max_write_delay = 9000;
		   ;

		 memory "hfuse"
			 size            = 1;
			 write           = "1 0 1 0  1 1 0 0  1 0 1 0  1 0 0 0",
							   "x x x x  x x x x  i i i i  i i i i";

			 read            = "0 1 0 1  1 0 0 0  0 0 0 0  1 0 0 0",
							   "x x x x  x x x x  o o o o  o o o o";
			min_write_delay = 9000;
			max_write_delay = 9000;
		   ;

		 memory "efuse"
			 size            = 1;
			 write           = "1 0 1 0  1 1 0 0  1 0 1 0  0 1 0 0",
							   "x x x x  x x x x  x x x x  x x x i";

			 read            = "0 1 0 1  0 0 0 0  0 0 0 0  1 0 0 0",
							   "x x x x  x x x x  o o o o  o o o o";
			min_write_delay = 9000;
			max_write_delay = 9000;
		 ;

		 memory "calibration"
			 size            = 2;
			 read            = "0  0  1  1   1  0  0  0    0 0 0 x  x x x x",
							   "0  0  0  0   0  0  0  a0   o o o o  o o o o";
		 ;
	  ;

#------------------------------------------------------------
# ATtiny4
#------------------------------------------------------------

part
    id		= "attiny4";
    desc	= "ATtiny4";
		avr910_devcode = 0x14;
    signature	= 0x1e 0x90 0x03;
		timeout		= 900;

    memory "flash"
        size			= 512;
        page_size	= 16;
        blocksize	= 128;
				readsize	= 256;
    ;

    memory "signature"
        size		= 3;
			 read            = "0 0 1 1  0 0 0 0  0 0 0 0  0 0 0 0",
							   "0 0 0 0  0 0 a1 a0  o o o o  o o o o";
			min_write_delay = 9000;
			max_write_delay = 9000;
    ;

    memory "calibration"
        size		= 1;
			 read            = "0 0 1 1  1 0 0 0  0 0 0 0  0 0 0 0",
							   "0 0 0 0  0 0 0 0  o o o o  o o o o";
			min_write_delay = 9000;
			max_write_delay = 9000;
    ;

    memory "fuse"
 			 size            = 	1;
			 read            = 	"0 1 0 1  0 0 0 0  0 0 0 0  0 0 0 0",
							   					"x x x x  x x x x  o o o o  o o o o";

			 write           = 	"1 0 1 0  1 1 0 0  1 0 1 0  1 0 0 0",
							   					"x x x x  x x x x  i i i i  i i i i";
 			min_write_delay = 9000;
			max_write_delay = 9000;
    ;

    memory "lock"
        size		= 1;
        read            = "0 1 0 1  1 0 0 0   0 0 0 0  0 0 0 0",
                          "x x x x  x x x x   o o o o  o o o o";

        write           = "1 0 1 0  1 1 0 0   1 1 1 0  0 0 0 0",
                          "x x x x  x x x x   i i i i  i i i i";
			min_write_delay = 9000;
			max_write_delay = 9000;
    ;
;

#------------------------------------------------------------
# ATtiny5
#------------------------------------------------------------

part
    id		= "attiny5";
    desc	= "ATtiny5";
		avr910_devcode = 0x15;
    signature	= 0x1e 0x90 0x03;
		timeout		= 900;

    memory "flash"
        size			= 512;
        page_size	= 16;
        blocksize	= 128;
				readsize	= 256;
    ;

    memory "signature"
        size		= 3;
			 read            = "0 0 1 1  0 0 0 0  0 0 0 0  0 0 0 0",
							   "0 0 0 0  0 0 a1 a0  o o o o  o o o o";
			min_write_delay = 9000;
			max_write_delay = 9000;
    ;

    memory "calibration"
        size		= 1;
			 read            = "0 0 1 1  1 0 0 0  0 0 0 0  0 0 0 0",
							   "0 0 0 0  0 0 0 0  o o o o  o o o o";
			min_write_delay = 9000;
			max_write_delay = 9000;
    ;

    memory "fuse"
 			 size            = 	1;
			 read            = 	"0 1 0 1  0 0 0 0  0 0 0 0  0 0 0 0",
							   					"x x x x  x x x x  o o o o  o o o o";

			 write           = 	"1 0 1 0  1 1 0 0  1 0 1 0  1 0 0 0",
							   					"x x x x  x x x x  i i i i  i i i i";
 			min_write_delay = 9000;
			max_write_delay = 9000;
    ;

    memory "lock"
        size		= 1;
        read            = "0 1 0 1  1 0 0 0   0 0 0 0  0 0 0 0",
                          "x x x x  x x x x   o o o o  o o o o";

        write           = "1 0 1 0  1 1 0 0   1 1 1 0  0 0 0 0",
                          "x x x x  x x x x   i i i i  i i i i";
			min_write_delay = 9000;
			max_write_delay = 9000;
    ;
;

#------------------------------------------------------------
# ATtiny9
#------------------------------------------------------------

part
    id		= "attiny9";
    desc	= "ATtiny9";
		avr910_devcode = 0x19;
    signature	= 0x1e 0x90 0x03;
		timeout		= 900;

    memory "flash"
        size			= 1024;
        page_size	= 16;
        blocksize	= 128;
				readsize	= 256;
    ;

    memory "signature"
        size		= 3;
			 read            = "0 0 1 1  0 0 0 0  0 0 0 0  0 0 0 0",
							   "0 0 0 0  0 0 a1 a0  o o o o  o o o o";
			min_write_delay = 9000;
			max_write_delay = 9000;
    ;

    memory "calibration"
        size		= 1;
			 read            = "0 0 1 1  1 0 0 0  0 0 0 0  0 0 0 0",
							   "0 0 0 0  0 0 0 0  o o o o  o o o o";
			min_write_delay = 9000;
			max_write_delay = 9000;
    ;

    memory "fuse"
 			 size            = 	1;
			 read            = 	"0 1 0 1  0 0 0 0  0 0 0 0  0 0 0 0",
							   					"x x x x  x x x x  o o o o  o o o o";

			 write           = 	"1 0 1 0  1 1 0 0  1 0 1 0  1 0 0 0",
							   					"x x x x  x x x x  i i i i  i i i i";
 			min_write_delay = 9000;
			max_write_delay = 9000;
    ;

    memory "lock"
        size		= 1;
        read            = "0 1 0 1  1 0 0 0   0 0 0 0  0 0 0 0",
                          "x x x x  x x x x   o o o o  o o o o";

        write           = "1 0 1 0  1 1 0 0   1 1 1 0  0 0 0 0",
                          "x x x x  x x x x   i i i i  i i i i";
			min_write_delay = 9000;
			max_write_delay = 9000;
    ;
;

#------------------------------------------------------------
# ATtiny10
#------------------------------------------------------------

part
    id		= "attiny10";
    desc	= "ATtiny10";
		avr910_devcode = 0x10;
    signature	= 0x1e 0x90 0x03;
		timeout		= 900;

    memory "flash"
        size			= 1024;
        page_size	= 16;
        blocksize	= 128;
				readsize	= 256;
    ;

    memory "signature"
        size		= 3;
			 read            = "0 0 1 1  0 0 0 0  0 0 0 0  0 0 0 0",
							   "0 0 0 0  0 0 a1 a0  o o o o  o o o o";
			min_write_delay = 9000;
			max_write_delay = 9000;
    ;

    memory "calibration"
        size		= 1;
			 read            = "0 0 1 1  1 0 0 0  0 0 0 0  0 0 0 0",
							   "0 0 0 0  0 0 0 0  o o o o  o o o o";
			min_write_delay = 9000;
			max_write_delay = 9000;
    ;

    memory "fuse"
 			 size            = 	1;
			 read            = 	"0 1 0 1  0 0 0 0  0 0 0 0  0 0 0 0",
							   					"x x x x  x x x x  o o o o  o o o o";

			 write           = 	"1 0 1 0  1 1 0 0  1 0 1 0  1 0 0 0",
							   					"x x x x  x x x x  i i i i  i i i i";
 			min_write_delay = 9000;
			max_write_delay = 9000;
    ;

    memory "lock"
        size		= 1;
        read            = "0 1 0 1  1 0 0 0   0 0 0 0  0 0 0 0",
                          "x x x x  x x x x   o o o o  o o o o";

        write           = "1 0 1 0  1 1 0 0   1 1 1 0  0 0 0 0",
                          "x x x x  x x x x   i i i i  i i i i";
			min_write_delay = 9000;
			max_write_delay = 9000;
    ;
;

#------------------------------------------------------------
# ATmega32u4
#------------------------------------------------------------

part
    id               = "atmega32u4";
    desc             = "ATmega32U4";
    signature        = 0x1e 0x95 0x87;
    has_jtag         = yes;
    stk500_devcode   = 0x04;
    avr910_devcode   = 0x04;
    chip_erase_delay = 9000;
    pagel            = 0xD7;
    bs2              = 0xA0;
    reset            = dedicated;
    pgm_enable       = "1 0 1 0  1 1 0 0    0 1 0 1  0 0 1 1",
                       "x x x x  x x x x    x x x x  x x x x";

    chip_erase       = "1 0 1 0  1 1 0 0    1 0 0 0  0 0 0 0",
                       "x x x x  x x x x    x x x x  x x x x";

    timeout		= 200;
    stabdelay		= 100;
    cmdexedelay		= 25;
    synchloops		= 32;
    bytedelay		= 0;
    pollindex		= 3;
    pollvalue		= 0x53;
    predelay		= 1;
    postdelay		= 1;
    pollmethod		= 1;

    pp_controlstack     =
        0x0E, 0x1E, 0x0F, 0x1F, 0x2E, 0x3E, 0x2F, 0x3F,
        0x4E, 0x5E, 0x4F, 0x5F, 0x6E, 0x7E, 0x6F, 0x7F,
        0x66, 0x76, 0x67, 0x77, 0x6A, 0x7A, 0x6B, 0x7B,
        0xBE, 0xFD, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00;
    hventerstabdelay    = 100;
    progmodedelay       = 0;
    latchcycles         = 5;
    togglevtg           = 1;
    poweroffdelay       = 15;
    resetdelayms        = 1;
    resetdelayus        = 0;
    hvleavestabdelay    = 15;
    chiperasepulsewidth = 0;
    chiperasepolltimeout = 10;
    programfusepulsewidth = 0;
    programfusepolltimeout = 5;
    programlockpulsewidth = 0;
    programlockpolltimeout = 5;

    idr                 = 0x31;
    spmcr               = 0x57;
    rampz               = 0x3b;
    allowfullpagebitstream = no;

    memory "eeprom"
        paged           = no; /* leave this "no" */
        page_size       = 8;  /* for parallel programming */
        size            = 1024;
        min_write_delay = 9000;
        max_write_delay = 9000;
        readback_p1     = 0x00;
        readback_p2     = 0x00;
        read            = "  1   0   1   0      0   0   0   0",
                          "  x   x   x   x      x a10  a9  a8",
                          " a7  a6  a5  a4     a3  a2  a1  a0",
                          "  o   o   o   o      o   o   o   o";

        write           = "  1   1   0   0      0   0   0   0",
                          "  x   x   x   x      x a10  a9  a8",
                          " a7  a6  a5  a4     a3  a2  a1  a0", 
                          "  i   i   i   i      i   i   i   i";

	loadpage_lo	= "  1   1   0   0      0   0   0   1",
			  "  0   0   0   0      0   0   0   0",
			  "  0   0   0   0      0  a2  a1  a0",
			  "  i   i   i   i      i   i   i   i";

	writepage	= "  1   1   0   0      0   0   1   0",
			  "  0   0   x   x      x a10  a9  a8",
			  " a7  a6  a5  a4     a3   0   0   0",
			  "  x   x   x   x      x   x   x   x";

	mode		= 0x41;
	delay		= 10;
	blocksize	= 8;
	readsize	= 256;
      ;

    memory "flash"
        paged           = yes;
        size            = 32768;
        page_size       = 128;
        num_pages       = 256;
        min_write_delay = 4500;
        max_write_delay = 4500;
        readback_p1     = 0x00;
        readback_p2     = 0x00;
        read_lo         = "  0   0   1   0      0   0   0   0",
                          "  0 a14 a13 a12    a11 a10  a9  a8",
                          " a7  a6  a5  a4     a3  a2  a1  a0",
                          "  o   o   o   o      o   o   o   o";

        read_hi         = "  0   0   1   0      1   0   0   0",
                          "  0 a14 a13 a12    a11 a10  a9  a8",
                          " a7  a6  a5  a4     a3  a2  a1  a0",
                          "  o   o   o   o      o   o   o   o";

        loadpage_lo     = "  0   1   0   0      0   0   0   0",
                          "  x   x   x   x      x   x   x   x",
                          "  x   x  a5  a4     a3  a2  a1  a0",
                          "  i   i   i   i      i   i   i   i";

        loadpage_hi     = "  0   1   0   0      1   0   0   0",
                          "  x   x   x   x      x   x   x   x",
                          "  x   x  a5  a4     a3  a2  a1  a0",
                          "  i   i   i   i      i   i   i   i";

        writepage       = "  0   1   0   0      1   1   0   0",
                          " a15 a14 a13 a12    a11 a10  a9  a8",
                          " a7  a6   x   x      x   x   x   x",
                          "  x   x   x   x      x   x   x   x";

	mode		= 0x41;
	delay		= 6;
	blocksize	= 128;
	readsize	= 128;
      ;

    memory "lfuse"
        size            = 1;
        write           = "1 0 1 0  1 1 0 0  1 0 1 0  0 0 0 0",
                          "x x x x  x x x x  i i i i  i i i i";

        read            = "0 1 0 1  0 0 0 0  0 0 0 0  0 0 0 0",
                          "x x x x  x x x x  o o o o  o o o o";
        min_write_delay = 9000;
        max_write_delay = 9000;
      ;

    memory "hfuse"
        size            = 1;
        write           = "1 0 1 0  1 1 0 0  1 0 1 0  1 0 0 0",
                          "x x x x  x x x x  i i i i  i i i i";

        read            = "0 1 0 1  1 0 0 0  0 0 0 0  1 0 0 0",
                          "x x x x  x x x x  o o o o  o o o o";
        min_write_delay = 9000;
        max_write_delay = 9000;
      ;

    memory "efuse"
        size            = 1;
        write           = "1 0 1 0  1 1 0 0  1 0 1 0  0 1 0 0",
                          "x x x x  x x x x  i i i i  i i i i";

        read            = "0 1 0 1  0 0 0 0  0 0 0 0  1 0 0 0",
                          "x x x x  x x x x  o o o o  o o o o";
        min_write_delay = 9000;
        max_write_delay = 9000;
      ;

    memory "lock"
        size            = 1;
        read            = "0 1 0 1  1 0 0 0   0 0 0 0  0 0 0 0",
                          "x x x x  x x x x   i i o o  o o o o";

        write           = "1 0 1 0  1 1 0 0   1 1 1 x  x x x x",
                          "x x x x  x x x x   i i i i  i i i i";
        min_write_delay = 9000;
        max_write_delay = 9000;
      ;

    memory "calibration"
        size            = 1;
        read            = "0 0 1 1  1 0 0 0    x x x x  x x x x",
                          "0 0 0 0  0 0 0 0    o o o o  o o o o";
      ;

    memory "signature"
        size            = 3;
        read            = "0  0  1  1   0  0  0  0   x  x  x  x   x  x  x  x",
                          "x  x  x  x   x  x a1 a0   o  o  o  o   o  o  o  o";
      ;
  ;

#------------------------------------------------------------
# AT90USB162
#------------------------------------------------------------

part
    id               = "at90usb162";
    desc             = "AT90USB162";
    stk500_devcode   = 0x05;
    avr910_devcode   = 0x05;
    has_jtag         = no;
    has_debugwire    = yes;
    signature        = 0x1e 0x94 0x82;
    chip_erase_delay = 9000;
    reset            = io;
    pgm_enable       = "1 0 1 0  1 1 0 0    0 1 0 1  0 0 1 1",
                       "x x x x  x x x x    x x x x  x x x x";
    chip_erase       = "1 0 1 0  1 1 0 0    1 0 0 x  x x x x",
                       "x x x x  x x x x    x x x x  x x x x";
    pagel            = 0xD7;
    bs2              = 0xC6;

    timeout		= 200;
    stabdelay		= 100;
    cmdexedelay		= 25;
    synchloops		= 32;
    bytedelay		= 0;
    pollindex		= 3;
    pollvalue		= 0x53;
    predelay		= 1;
    postdelay		= 1;
    pollmethod		= 1;
    pp_controlstack     =
        0x0E, 0x1E, 0x0F, 0x1F, 0x2E, 0x3E, 0x2F, 0x3F,
        0x4E, 0x5E, 0x4F, 0x5F, 0x6E, 0x7E, 0x6F, 0x7F,
        0x66, 0x76, 0x67, 0x77, 0x6A, 0x7A, 0x6B, 0x7B,
        0xBE, 0xFD, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00;
    hventerstabdelay    = 100;
    progmodedelay       = 0;
    latchcycles         = 5;
    togglevtg           = 1;
    poweroffdelay       = 15;
    resetdelayms        = 1;
    resetdelayus        = 0;
    hvleavestabdelay    = 15;
    chiperasepulsewidth = 0;
    chiperasepolltimeout = 10;
    programfusepulsewidth = 0;
    programfusepolltimeout = 5;
    programlockpulsewidth = 0;
    programlockpolltimeout = 5;

    memory "eeprom"
        paged           = no; /* leave this "no" */
        page_size       = 4;  /* for parallel programming */
        size            = 512;
        num_pages       = 128;
        min_write_delay = 9000;
        max_write_delay = 9000;
        readback_p1     = 0x00;
        readback_p2     = 0x00;
        read            = "  1   0   1   0      0   0   0   0",
                          "  0   0   0   0    a11 a10  a9  a8",
                          " a7  a6  a5  a4     a3  a2  a1  a0",
                          "  o   o   o   o      o   o   o   o";

        write           = "  1   1   0   0      0   0   0   0",
                          "  0   0   0   0    a11 a10  a9  a8",
                          " a7  a6  a5  a4     a3  a2  a1  a0",
                          "  i   i   i   i      i   i   i   i";

	loadpage_lo	= "  1   1   0   0      0   0   0   1",
			  "  0   0   0   0      0   0   0   0",
			  "  0   0   0   0      0   0  a1  a0",
			  "  i   i   i   i      i   i   i   i";

	writepage	= "  1   1   0   0      0   0   1   0",
                          "  0   0   0   0    a11 a10  a9  a8",
                          " a7  a6  a5  a4     a3  a2   0   0",
			  "  x   x   x   x      x   x   x   x";

	mode		= 0x41;
	delay		= 20;
	blocksize	= 4;
	readsize	= 256;
      ;

    memory "flash"
        paged           = yes;
        size            = 16384;
        page_size       = 128;
        num_pages       = 128;
        min_write_delay = 4500;
        max_write_delay = 4500;
        readback_p1     = 0x00;
        readback_p2     = 0x00;
        read_lo         = "  0   0   1   0      0   0   0   0",
                          "a15 a14 a13 a12    a11 a10  a9  a8",
                          " a7  a6  a5  a4     a3  a2  a1  a0",
                          "  o   o   o   o      o   o   o   o";

        read_hi         = "  0   0   1   0      1   0   0   0",
                          "a15 a14 a13 a12    a11 a10  a9  a8",
                          " a7  a6  a5  a4     a3  a2  a1  a0",
                          "  o   o   o   o      o   o   o   o";

        loadpage_lo     = "  0   1   0   0      0   0   0   0",
                          "  x   x   x   x      x   x   x   x",
                          "  x   x  a5  a4     a3  a2  a1  a0",
                          "  i   i   i   i      i   i   i   i";

        loadpage_hi     = "  0   1   0   0      1   0   0   0",
                          "  x   x   x   x      x   x   x   x",
                          "  x   x  a5  a4     a3  a2  a1  a0",
                          "  i   i   i   i      i   i   i   i";

        writepage       = "  0   1   0   0      1   1   0   0",
                          "a15 a14 a13 a12    a11 a10  a9  a8",
                          " a7  a6   x   x      x   x   x   x",
                          "  x   x   x   x      x   x   x   x";

	mode		= 0x41;
	delay		= 6;
	blocksize	= 128;
	readsize	= 256;
      ;

    memory "lfuse"
        size            = 1;
        write           = "1 0 1 0  1 1 0 0  1 0 1 0  0 0 0 0",
                          "x x x x  x x x x  i i i i  i i i i";

        read            = "0 1 0 1  0 0 0 0  0 0 0 0  0 0 0 0",
                          "x x x x  x x x x  o o o o  o o o o";
        min_write_delay = 9000;
        max_write_delay = 9000;
      ;

    memory "hfuse"
        size            = 1;
        write           = "1 0 1 0  1 1 0 0  1 0 1 0  1 0 0 0",
                          "x x x x  x x x x  i i i i  i i i i";

        read            = "0 1 0 1  1 0 0 0  0 0 0 0  1 0 0 0",
                          "x x x x  x x x x  o o o o  o o o o";
        min_write_delay = 9000;
        max_write_delay = 9000;
      ;

    memory "efuse"
        size            = 1;
        write           = "1 0 1 0  1 1 0 0  1 0 1 0  0 1 0 0",
                          "x x x x  x x x x  i i i i  i i i i";

        read            = "0 1 0 1  0 0 0 0  0 0 0 0  1 0 0 0",
                          "x x x x  x x x x  o o o o  o o o o";
        min_write_delay = 9000;
        max_write_delay = 9000;
      ;

    memory "lock"
        size            = 1;
        read            = "0 1 0 1  1 0 0 0   0 0 0 0  0 0 0 0",
                          "x x x x  x x x x   x x o o  o o o o";

        write           = "1 0 1 0  1 1 0 0   1 1 1 x  x x x x",
                          "x x x x  x x x x   1 1 i i  i i i i";
        min_write_delay = 9000;
        max_write_delay = 9000;
      ;

    memory "calibration"
        size            = 1;
        read            = "0 0 1 1  1 0 0 0    0 0 0 x  x x x x",
                          "0 0 0 0  0 0 0 0    o o o o  o o o o";
      ;
    memory "signature"
        size            = 3;
        read            = "0  0  1  1   0  0  0  0   0  0  0  x   x  x  x  x",
                          "x  x  x  x   x  x a1 a0   o  o  o  o   o  o  o  o";
      ;
  ;



