// LED-Candle.c
// Dual LED Candle with daylight sensor and power saving

#include <stdlib.h>
#include <stdbool.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/sleep.h>
#include <avr/power.h>
#include <util/delay.h>
#include <libNoter/pin_io_macros.h>

#define LED1							B,0											// OCR0A
#define LED2							B,1											// OCR0B
#define RC_PIN 					B,2											// PB2

#define LED1_PWM				OCR0A										// PB0
#define LED2_PWM				OCR0B										// PB1

#define TURN_ON 900
#define TURN_OFF 300
#define ON 1
#define OFF 0
volatile uint16_t light;

ISR(WDT_vect, ISR_BLOCK){
	// measure resistance across photocell by charging 
	// a capacitor and then letting it discharge thru
	// the photocell and measuring the discharge time.
	OUTPUT(RC_PIN);																	// OUTPUT RC pin
	light = 0;																			// reset counter

	SET(RC_PIN);																		// charge the capacitor
	_delay_us(100);																	// for a moment then
	INPUT(RC_PIN);																	// setup high impedence
	CLEAR(RC_PIN);																	// and turn off power (no pull-up)

	// time voltage drain on capacitor
	for(;READ(RC_PIN);){														// pin at logical 0?
		_delay_us(1);																	// nope, keep counting
		light++;
		if(light>(TURN_ON*3)){												// it's definatly dark
			OUTPUT(RC_PIN);															// drain the capacitor
			_delay_us(100);
			break;
		}
	}
}

//---------------------------------------------------------------------------------------
int main() {
	// bump clock to 8MHz
	CCP = 0xD8;																				// enable protected change
	CLKPSR = 0;                                       // set 8MHz prescaler = 1

	// power reduction
	ACSR = _BV(ACD);																	// shutdown analog comparator
	DIDR0 = (_BV(ADC0D) | _BV(ADC1D));								// disable digital input on PWM pins
	power_adc_disable();															// disable adc

	// setup ports
	DDRB = 0x7;																				// PB0, PB1, PB2 OUTPUT

	// startup watchdog timer
	CCP = 0xD8;																				// enable protected change
	WDTCSR = _BV(WDP2) | _BV(WDP1);										// 1 second timeout
	WDTCSR |= _BV(WDIE);															// interrupt on timeout
	sei();																						// enable global interrupts
	uint32_t rand_value;
	bool state = OFF;
	for(;;){
		if(light<=TURN_OFF){														// is it light?
			state = OFF;
		} else {
			if(light>=TURN_ON){														// or is it dark?
				state = ON;
			}
		}
		if(state == OFF){
			if(TCCR0B){																		// nope, timer running?
				TCCR0B = 0;																	// yep, stop it
				TCCR0A = 0;
				CLEAR(LED1);																// turn off pwm outputs
				CLEAR(LED2);
			}
			set_sleep_mode(SLEEP_MODE_PWR_DOWN);					// and powerdown until watchdog wakes
			sleep_enable();
			sleep_cpu();
			sleep_disable();
		} else {	// if not OFF then has to be ON
			if(TCCR0B == 0){																		// timer running?
				LED2_PWM = 0x80; 																	// nope, set OCR0A min
				TCCR0A = _BV(COM0A1) | _BV(COM0B1) | _BV(WGM00);	// start timer
				TCCR0B = _BV(CS00) | _BV(WGM02);
				srand(light);																			// new random start
			}
			LED1_PWM = LED2_PWM;																// twinkle the lights
			rand_value = rand();
		  LED2_PWM = (rand_value % 0xFF)|0x80;
			_delay_ms(98);
		}
	}
}


