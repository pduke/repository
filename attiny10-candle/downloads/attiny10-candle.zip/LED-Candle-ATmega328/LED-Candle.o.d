LED-Candle.o: LED-Candle.c ../libNoter/pin_io_macros.h \
 ../libNoter/lcd_Noter_4_bit.h

../libNoter/pin_io_macros.h:

../libNoter/lcd_Noter_4_bit.h:
