// LED-Candle.c
// Dual LED Candle with daylight sensor and power saving

#include <stdlib.h>
#include <stdbool.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/sleep.h>
#include <avr/power.h>
#include <util/delay.h>
#include <libNoter/pin_io_macros.h>
#include <libNoter/lcd_Noter_4_bit.h>

FILE lcd_stream;

#define B_GND						C,1			// ground divider for measure
#define V_BAT						C,0			// measure divider for battery


#define LED1							B,1											// OCR1A
#define LED2							B,2											// OCR1B
#define LED3							D,5											// OCR0A
//#define LED4							D,6											// OCR0B
#define RC_PIN 					C,5											// PC5

#define LED1_PWM				OCR1A										// PB1
#define LED2_PWM				OCR1B										// PB2
#define LED3_PWM				OCR0B										// PD5
//#define LED4_PWM				OCR0A										// PD6

#define TURN_ON 1200
#define TURN_OFF 400
#define ON 1
#define OFF 0
volatile uint16_t light;

ISR(WDT_vect, ISR_BLOCK){
	// measure resistance across photocell by charging 
	// a capacitor and then letting it discharge thru
	// the photocell and measuring the discharge time.

	OUTPUT(RC_PIN);																	// OUTPUT RC pin
	light = 0;																			// reset counter

	SET(RC_PIN);																		// charge the capacitor
	_delay_us(100);																	// for a moment then
	INPUT(RC_PIN);																	// setup high impedence
	CLEAR(RC_PIN);																	// and turn off power (no pull-up)

	// time voltage drain on capacitor
	for(;READ(RC_PIN);){														// pin at logical 0?
		_delay_us(1);																	// nope, keep counting
		light++;
		if(light>(TURN_ON*3)){												// it's definatly dark
			OUTPUT(RC_PIN);															// drain the capacitor
			_delay_us(200);
			break;
		}
	}
}

//---------------------------------------------------------------------------------------
int main() {
	// Initialize LCD and identify
//	lcd_init(4, 20);
	lcd_init(2, 16);
	lcd_cursor_blink(true);
	fdev_setup_stream(&lcd_stream, lcd_putchar, 0, _FDEV_SETUP_WRITE); 
	fprintf_P(&lcd_stream, PSTR("LED-Candle u328p"));

	// power reduction
	PRR = _BV(PRTWI)
			| _BV(PRTIM2)
			| _BV(PRSPI)
			| _BV(PRUSART0);

	// disable digital inputs
	DIDR0 = _BV(ADC0D)
				| _BV(ADC1D)
				| _BV(ADC2D)
				| _BV(ADC3D)
				| _BV(ADC4D);


	// setup ports
	OUTPUT(LED1);
	OUTPUT(LED2);
	OUTPUT(LED3);
//	OUTPUT(LED4);

	// startup watchdog timer
	WDTCSR = _BV(WDCE) | _BV(WDE);									// 1 second timeout
	WDTCSR = _BV(WDIE) | _BV(WDP1) | _BV(WDP2);			// interrupt on timeout

	sei();																					// enable global interrupts

	uint32_t rand_value;
	bool state = OFF;
	uint16_t m_count = 0;
	for(;;){
		if(light<=TURN_OFF){													// is it light?
			state = OFF;
		} else {
			if(light>=TURN_ON){													// or is it dark?
				state = ON;
			}
		}
		if(state == OFF){
			if(TCCR1B){																		// nope, timer running?
				TCCR1B = 0;																	// yep, stop it
				TCCR1A = 0;
				TCCR0B = 0;																	// yep, stop it
				TCCR0A = 0;
				CLEAR(LED1);																// turn off pwm outputs
				CLEAR(LED2);
				CLEAR(LED3);																// turn off pwm outputs
//				CLEAR(LED4);
			}
			set_sleep_mode(SLEEP_MODE_PWR_DOWN);	// and powerdown until watchdog wakes
			sleep_enable();
			sleep_cpu();
			sleep_disable();
		} else {	// if not OFF then has to be ON
			if(TCCR1B == 0){																		// timer running?
				LED1_PWM = 0x80; 																	// nope, set OCR0A min
				TCCR1A = _BV(COM1A1) | _BV(COM1B1) | _BV(WGM10);	// start timer
				TCCR1B = _BV(CS10) | _BV(WGM12);
//				TCCR0A = _BV(COM0A1) | _BV(COM0B1) | _BV(WGM01) | _BV(WGM00);
//				TCCR0A = _BV(COM0A1)| _BV(WGM01) | _BV(WGM00);
				TCCR0A = _BV(COM0B1)| _BV(WGM01) | _BV(WGM00);
				TCCR0B = _BV(CS00);
				srand(light);																			// new random start
			}
			rand_value = rand();																// twinkle the lights
//			LED4_PWM = LED3_PWM;
			LED3_PWM = LED2_PWM;
			LED2_PWM = LED1_PWM;
		  LED1_PWM = ((rand_value % 0xFF)|0x80)*0.5;
			_delay_ms(98);
		}
	}
}


