LED-Candle.o: LED-Candle.c ../libNoter/pin_io_macros.h

../libNoter/pin_io_macros.h:
