// LED-Candle.c
// Dual LED Candle with daylight sensor and power saving

#include <stdlib.h>
#include <stdbool.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/sleep.h>
#include <avr/power.h>
#include <util/delay.h>
#include <libNoter/pin_io_macros.h>

#define LED1							B,0											// OCR0A
#define LED2							B,1											// OCR0B
#define LED3							B,4											// OCR1B
#define RC_PIN 					B,3											// PB3

#define LED1_PWM				OCR0A										// PB0
#define LED2_PWM				OCR0B										// PB1
#define LED3_PWM				OCR1B										// PD4

#define TURN_ON 1200
#define TURN_OFF 400
#define ON 1
#define OFF 0
volatile uint16_t light = 0;


ISR(WDT_vect, ISR_NOBLOCK){
	// measure resistance across photocell by charging 
	// a capacitor and then letting it discharge thru
	// the photocell and measuring the discharge time.
	OUTPUT(RC_PIN);																	// OUTPUT RC pin
	light = 0;																			// reset counter

	SET(RC_PIN);																		// charge the capacitor
	_delay_us(100);																	// for a moment then
	INPUT(RC_PIN);																	// setup high impedence
	CLEAR(RC_PIN);																	// and turn off power (no pull-up)

	// time voltage drain on capacitor
	for(;READ(RC_PIN);){														// pin at logical 0?
		_delay_us(1);																	// nope, keep counting
		light++;
		if(light>(TURN_ON*3)){												// it's definatly dark
			OUTPUT(RC_PIN);															// drain the capacitor
			_delay_us(200);
			break;
		}
	}
}
//---------------------------------------------------------------------------------------
int main() {
	// power reduction
	PRR = _BV(PRUSI)
			| _BV(PRADC);

	// disable digital inputs
	DIDR0 = _BV(ADC1D)
				| _BV(ADC2D);

	// setup ports
	_delay_ms(100);
	OUTPUT(LED1);
	OUTPUT(LED2);
	OUTPUT(LED3);
	SET(LED1);
	SET(LED2);
	SET(LED3);
	_delay_ms(100);
	CLEAR(LED1);
	CLEAR(LED2);
	CLEAR(LED3);

	// startup watchdog timer, 1 sec timeout, interrupt
	WDTCR = _BV(WDIE) | _BV(WDP1) | _BV(WDP2);
	sei();																					// enable global interrupts

	uint32_t rand_value;
	bool state = OFF;
	int8_t led1_step;
	int8_t led2_step;
	int8_t led3_step;
	uint8_t led1_final = 80;
	uint8_t led2_final = 80;
	uint8_t led3_final = 80;
	uint8_t new_final;
	uint8_t delay_ms;
	uint8_t chase_direction;
	uint8_t chase_change = 0;

	for(;;){
		if(light<=TURN_OFF){													// is it light?
			state = OFF;
		} else {
			if(light>=TURN_ON){													// or is it dark?
				state = ON;
			}
		}
		if(state == OFF){
			if(TCCR0B){																		// nope, timer running?
				GTCCR = 0;
				TCCR1 = 0;																	// yep, stop it
				TCCR0B = 0;																	// yep, stop it
				TCCR0A = 0;
				CLEAR(LED1);																// turn off pwm outputs
				CLEAR(LED2);
				CLEAR(LED3);																// turn off pwm outputs
			}
			set_sleep_mode(SLEEP_MODE_PWR_DOWN);	// and powerdown until watchdog wakes
			sleep_enable();
			sleep_cpu();
			sleep_disable();
		} else {	// if not OFF then has to be ON
			if(TCCR0B == 0){																// timer running?
				LED1_PWM = 128; 																// nope, set OCRxx min
				LED2_PWM = 128;
				LED3_PWM = 128;
				// setup timer1
				OCR1C = 0xFF;
				GTCCR = _BV(PWM1B) | _BV(COM1B1);
				TCCR1 = _BV(CS10);
				// setup timer0
				TCCR0A = _BV(COM0A1) | _BV(COM0B1) | _BV(WGM01) | _BV(WGM00);
				TCCR0B = _BV(CS00);
				srand(light);																			// new random start
			}
			rand_value = rand();																// twinkle the lights

			#define STEPS 3
			#define DELAY_MIN 80
			#define DELAY_MAX 130

			delay_ms = ((rand_value % (DELAY_MAX-DELAY_MIN))+DELAY_MIN) / STEPS;

			if(chase_change++&4){
				chase_direction = rand_value & 0x03;
			}
			new_final = ((rand_value % 0xFF)|0x80)>>1;
			if(chase_direction==0){
				led3_final = led2_final;
				led2_final = led1_final;
				led1_final = new_final;
			}
			if(chase_direction==1){
				led1_final = led2_final;
				led2_final = led3_final;
				led3_final = new_final;
			}
			if(chase_direction==2){
				led1_final = led3_final;
				led3_final = led2_final;
				led2_final = new_final;
			}
			if(chase_direction==3){
				led2_final = led1_final;
				led1_final = led3_final;
				led3_final = new_final;
			}

			led3_step = -((LED3_PWM - led3_final)/STEPS);
			led2_step = -((LED2_PWM - led2_final)/STEPS);
			led1_step = -((LED1_PWM - led1_final)/STEPS);

			for(uint8_t i=0;i<(STEPS-1);i++){
				LED3_PWM += led3_step;
				LED2_PWM += led2_step;
				LED1_PWM += led1_step;
				for(uint8_t id=0;id<delay_ms;id++) _delay_ms(1);
			}

			LED3_PWM = led3_final;
			LED2_PWM = led2_final;
			LED1_PWM = led1_final;
			for(uint8_t id=0;id<delay_ms;id++) _delay_ms(1);
		}
	}
}


