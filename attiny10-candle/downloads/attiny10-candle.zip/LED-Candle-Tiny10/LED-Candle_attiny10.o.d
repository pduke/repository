LED-Candle_attiny10.o: LED-Candle_attiny10.c
