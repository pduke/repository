/* 
 Device with ATMega32U4, Arduino Leonardo board
 keyboard libary required
 Title: Keyboard Message + keep alive (twofun.ino)
 Author: Paul Duke  1/5/2024

 This program has two funcitons: 
  Keyboard keep alive by pressing and releasing the shift key about once a minute.
  Text string entry, I use for common password. Press the button and the text is sent.

  There is also a setup function where various things can be configured including the
  text string to send when the button is pressed. The device is either in setup mode
  or run mode. When in setup use a vt100 type terminal emulator to connect to the
  ttyusb port of the device at 9600 and you'll get the setup menu. When in run mode (kb simulation)
  the setup screen will be blank as the device and do either kb emulation or tty io
  at a given time but not both at the same time. Hold the button for more than 2 sec
  to enter setup mode if in run mode. Wait about 7 seconds for the device to reboot when
  changing modes. After setup go back to run mode by selecting exit setup.

 */
 
#define COLORS 8
const unsigned long Black     = 0x000000;
const unsigned long White     = 0xFFFFFF;
const unsigned long Red       = 0xFF0000;
const unsigned long Lime      = 0x00FF00;
const unsigned long Blue      = 0x0000FF;
const unsigned long Yellow    = 0xFFFF00;
const unsigned long Cyan      = 0x00FFFF;
const unsigned long Magenta   = 0xFF00FF;

char *Name[COLORS]={"Black","White","Red","Lime","Blue","Yellow","Cyan","Magenta"};
unsigned long Hex[COLORS]={0x000000,0xFFFFFF,0xFF0000,0x00FF00,0x0000FF,0xFFFF00,0x00FFFF,0xFF00FF};

char *colorHexToName(unsigned long colorHex){
  for(int i = 0;i<COLORS;i++){
    if(colorHex==Hex[i]) return Name[i];
    }
}


#include "Keyboard.h"
#include <EEPROM.h>
#include <stdarg.h>
struct mEEPROM { // eeprom structure
  byte version;     // eeprom format id
  byte mode;        // run or setup?
  bool kpAlive;     // keep alive enabled T/F
  int kpSeconds;    // keep alive period in seconds
  bool sendTxt;         // send text when button pressed enabled T/F
  char txtString[101];   // text to send 
  bool includeCR;        // append cr to text T/F
  bool ledEnabled;            // use led when in run mode? T/F
  int ledPower;         // power level 0 - 100%
  int ledFlashPower;    // just different for activity indication
  unsigned long clrConnectWait;
  unsigned long clrSetup;
  unsigned long clrRun;
  bool showActivity; // blink or dim the led when transmitting (run mode)
  char adminPwd[51];    // protect setup
  } eData;

const int buttonPin = 4;          // input pin for pushbutton
const int PIN_RED    = 5;         // RGB LED pins
const int PIN_BLUE   = 6;
const int PIN_GREEN  = 9;
int previousButtonState = HIGH;   // for checking the state of a pushButton
const int BUFFER_SIZE = 128;
char buf[BUFFER_SIZE];
const byte setUP = 'S';
const byte runIT = 'R';
const byte no ='n';
const byte yes ='y';
unsigned long wasPressed;  // ms timer when the button was pressed
const unsigned long msChangeMode = 3000; // longer than this .. change mode and reboot
bool readyToSend = false;

unsigned long lastKpAlive = 0;
bool startedKp = false;

bool promptYN(char *text){
  Serial.print(text);
  Serial.print(" (y/n) ");
  buf[0] = 0;
  while(buf[0]!='y' and buf[0]!='n'){
    while(!Serial.available()){  // wait for a character
      // if button pressed more than 3 sec then change mode and reboot
      buttonDown();
      } 
    Serial.readBytes(buf, 1); // get it
  }
  Serial.println(buf); // echo it
  if(buf[0]=='y') {
    return true;
  } else {
    return false;
  }
}

void color( unsigned long rgb, int brightness){
  analogWrite(PIN_RED,   ((rgb & 0xFF0000)>>16)*brightness/100);
  analogWrite(PIN_GREEN, ((rgb & 0x00FF00)>>8)*brightness/100);
  analogWrite(PIN_BLUE,  ((rgb & 0x0000FF))*brightness/100);
}

//void(* reBoot) (void) = 0; //declare reboot/reset function at address 0
void reBoot(){
  pinMode(A1,  OUTPUT); // the pin opens LOW and resets the leonardo
  digitalWrite(A1, LOW); // so this write doesn't really get executed, but just in case ...
}



void promptString( char *text, char *target, int length){

  char tmp;
  Serial.print(text);
  Serial.print(" ");
  memset(target,0x00,length);
  while(strlen(target)<length-1){
    while(!Serial.available()){  // wait for a character
      // if button pressed more than 3 sec then change mode and reboot
      buttonDown();
      } 
    tmp = Serial.read(); // get it
    //Serial.println(tmp, HEX);
    if(tmp==13) return;
    if(tmp>=33 && tmp <=126){ // printable ascii chars are  33 to 126
      target[strlen(target)]=tmp;
      Serial.print(tmp); // echo
    }
    if(tmp==0x7F){ // backspace key ... del the last char
      if(strlen(target)>0) target[strlen(target)-1]=0x00;
      Serial.print(F("\033[1D"));
      Serial.print(" ");
      Serial.print(F("\033[1D"));
    }
  }
}


int promptNum( char *text, int min, int max){
  char target[20];
  char tmp;
  Serial.print(text);
  Serial.print(" (");
  Serial.print(min);
  Serial.print(" to ");
  Serial.print(max);
  Serial.print(") ");
  memset(target,0x00,sizeof(target));
  while(strlen(target)<sizeof(target)-1){
    while(!Serial.available()){  // wait for a character
      // if button pressed more than a few sec then change mode and reboot
      buttonDown();
      } 
    tmp = Serial.read(); // get it
    //Serial.println(tmp, HEX);
    if(tmp==13 && atoi(target)>=min) return(atoi(target));
    if(tmp>='0' && tmp <='9'){ // nums
      target[strlen(target)]=tmp;
      if(atoi(target)<=max){
        Serial.print(tmp); // echo
      } else {
        if(strlen(target)) target[strlen(target)-1]=0x00;
      }
    }
    if(tmp==0x7F){ // backspace key ... del the last char
      if(strlen(target)>0){
        target[strlen(target)-1]=0x00;
        Serial.print(F("\033[1D"));
        Serial.print(" ");
        Serial.print(F("\033[1D"));
      }
    }
  }
}



unsigned long promptColor(char * text){
  for(int i = 0;i<COLORS;i++){
    sprintf(buf, "%d - %s", i, Name[i]); 
    Serial.println(buf);
    }
  return( Hex[promptNum(text, 0, COLORS-1)]);     
}

bool buttonDown(){
  int buttonState = digitalRead(buttonPin);
  if(buttonState == HIGH){
    if(buttonState != previousButtonState){
      wasPressed = millis();
      previousButtonState = buttonState; 
 //     readyToSend = false;
      delay(100);
    }
  } else {
    wasPressed = millis();
  }
  if(millis() - wasPressed > msChangeMode){ // change mode and reboot
    if(eData.mode==setUP){
      eData.mode=runIT;
    }else{
      eData.mode=setUP;
    }
    // update eeprom
    EEPROM.put(0, eData);
    reBoot();
  }
}
//======================================================================================


void setup() {
  EEPROM.get(0, eData);
//  eData.version = '0';
  if(eData.version != '2'){ // initalize new chip
    eData.version = '2';
//    eData.mode = runIT;
    eData.mode = setUP;
    eData.kpAlive = true;
    eData.kpSeconds = 55;
    eData.sendTxt = true;
    strcpy(eData.txtString, "test-txt");
    eData.includeCR = true;
    eData.ledEnabled = true;
    eData.ledPower = 100;
    eData.ledFlashPower=50;
    eData.clrConnectWait = Red;
    eData.clrSetup = White;
    eData.clrRun = Blue;
    eData.showActivity = true;
    strcpy(eData.adminPwd, "admin");
    EEPROM.put(0, eData);
  }
  //eData.mode = setUP;
  if(eData.mode==setUP){ // setup via serial
    Serial.begin(9600);
    color(eData.clrConnectWait, eData.ledPower);
    while (!Serial) { // wait for serial port to connect
      buttonDown();
    } 
    color(Black, 0);
  } else { // run mode
   Keyboard.begin();
   delay(1000); // give usb a sec to connect
  }
  pinMode(buttonPin, INPUT);
  pinMode(PIN_RED,   OUTPUT);
  pinMode(PIN_GREEN, OUTPUT);
  pinMode(PIN_BLUE,  OUTPUT);
}
//--------------------------------------------------------------------------------------

char *sTrue = "ON";
char *sFalse = "OFF";
void loop() {
  if(eData.mode==setUP){ // setup via serial
    color(eData.clrSetup, eData.ledPower);
    Serial.print(F("\033[0H\033[0J"));
    Serial.println(F("Keep Alive:"));
    sprintf_P(buf, PSTR(" 1 - kpAlive = %s"), eData.kpAlive?sTrue:sFalse);            Serial.println(buf);
    sprintf_P(buf, PSTR(" 2 - kpSeconds = %d"), eData.kpSeconds);                     Serial.println(buf);
    Serial.println(F("Button Text:"));
    sprintf_P(buf, PSTR(" 3 - sendTxt = %s"), eData.sendTxt?sTrue:sFalse);            Serial.println(buf);
    sprintf_P(buf, PSTR(" 4 - txtString = %s"), eData.txtString);                     Serial.println(buf);
    sprintf_P(buf, PSTR(" 5 - includeCR = %s"), eData.includeCR?sTrue:sFalse);        Serial.println(buf);
    Serial.println(F("LED:"));
    sprintf_P(buf, PSTR(" 6 - ledEnabled = %s"), eData.ledEnabled?sTrue:sFalse);      Serial.println(buf);
    sprintf_P(buf, PSTR(" 7 - showActivity = %s"), eData.showActivity?sTrue:sFalse);  Serial.println(buf);
    sprintf_P(buf, PSTR(" 8 - ledPower = %d%%"), eData.ledPower);                     Serial.println(buf);
    sprintf_P(buf, PSTR(" 9 - ledFlashPower = %d%%"), eData.ledFlashPower);                     Serial.println(buf);
    Serial.println(F("Status Colors:"));
    sprintf_P(buf, PSTR(" A - clrConnectWait = %s"), colorHexToName(eData.clrConnectWait));         Serial.println(buf);
    sprintf_P(buf, PSTR(" B - clrSetup = %s"), colorHexToName(eData.clrSetup));                     Serial.println(buf);
    sprintf_P(buf, PSTR(" C - clrRun = %s"), colorHexToName(eData.clrRun));                         Serial.println(buf);
    Serial.println(F("Exit:"));
    sprintf_P(buf, PSTR(" D - leave setup"));                                         Serial.println(buf);
    Serial.println("");
    Serial.print(F("Select: "));
    String valid = "0123456789ABCD";
    buf[0]='X';
    buf[1]=0;
    while(valid.indexOf(buf)<0){
      while(!Serial.available()){  // wait for a character
        // if button pressed more than 3 sec then change mode and reboot
        buttonDown();
      }
      buf[0]=Serial.read();
      if(buf[0] >= 'a' && buf[0] <= 'z') buf[0] -= 32; // make upper case
    } 
    Serial.println(buf[0]); // echo
    Serial.println("");
    switch(buf[0]){
      case '1':
        eData.kpAlive = promptYN("Enable KeepAlive?");
        break;
      case '2':
        eData.kpSeconds = promptNum("Seconds between keep alive broadcasts?", 5, 999);
        break;
      case '3':
        eData.sendTxt = promptYN("Enable button text?");
        break;
      case '4':
        promptString("Enter text to send?", eData.txtString, sizeof(eData.txtString));
        break;
      case '5':
        eData.includeCR = promptYN("Send CR after text?");
        break;
      case '6':
        eData.ledEnabled = promptYN("Enable LED during RUN mode?");
        break;
      case '7':
        eData.showActivity = promptYN("Do activity blinking?");
        break;
      case '8':
        eData.ledPower = promptNum("LED power level percent?", 1, 100);
        break;
      case '9':
        eData.ledFlashPower = promptNum("LED Flash power level percent?", 0, 100);
        break;
      case 'A':
        eData.clrConnectWait = promptColor("What LED color when waiting for tty to connect?");
        break;
      case 'B':
        eData.clrSetup = promptColor("What LED color when in SETUP?");
        break;
      case 'C':
        eData.clrRun = promptColor("What LED color when in RUN state?");
        break;
      case 'D':
        if(eData.mode==setUP){
          eData.mode=runIT;
        }else{
          eData.mode=setUP;
        }
        // update eeprom
        EEPROM.put(0, eData);
        reBoot();
        break;
      default:
        break;
    }
    EEPROM.put(0, eData);
    
  } else { // run mode     ..............................................
    if(eData.ledEnabled){
      color(eData.clrRun, eData.ledPower); 
    } else {
      color(eData.clrRun, Black); 
    }
    
    if(eData.sendTxt){
      if(digitalRead(buttonPin)==HIGH && !readyToSend){ // button down
        readyToSend = true;
      } 
      if(digitalRead(buttonPin)==LOW){ // button up
        if(readyToSend){
          if(eData.ledEnabled && eData.showActivity) color(eData.clrRun, eData.ledFlashPower);
          Keyboard.print(eData.txtString);
          if(eData.includeCR){
            Keyboard.press(KEY_RETURN);
            Keyboard.releaseAll();
          }
          if(eData.ledEnabled) color(eData.clrRun, eData.ledPower);
          delay(100); // debounce
        }
        readyToSend = false;
      }
      buttonDown(); // check for reset
    }
    
    if(eData.kpAlive){
      if((!startedKp) || ((millis()-lastKpAlive)>((unsigned long)eData.kpSeconds*1000UL))){
        startedKp=true;
        lastKpAlive=millis();
        if(eData.ledEnabled && eData.showActivity) color(eData.clrRun, eData.ledFlashPower);
        Keyboard.press(KEY_CAPS_LOCK); 
        Keyboard.releaseAll(); 
        delay(10);
        Keyboard.press(KEY_CAPS_LOCK); 
        Keyboard.releaseAll(); 
        delay(200);
      }
    }
  }
}
